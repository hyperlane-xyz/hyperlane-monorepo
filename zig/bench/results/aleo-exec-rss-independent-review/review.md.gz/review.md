# Independent Aleo Session exec/RSS review

Accepted scoped read-only review: no unresolved process-ownership, deadline/cancel, typed-exec-error or pipe/reaping blocker on the frozen owner source. No reviewer edits, compilation or test execution. Source hashes matched before/after review and matched the owner's final freeze map.

Root cause is reproduced, not hypothetical: the old Session.spawn checked /proc RSS immediately after fork, before exec. A touched256MiB parent plus3000 public argv entries made the48MiB Python worker fail the inherited-parent RSS check. The owner preserved that failing trace. RSS must measure the worker image; the pre-exec stage still requires its original time/cancel controls.

Code reviewed:

- worker.zig:40–44 transfers the spawned child into an owned Session and installs error cleanup before awaiting exec. Environment/stdio ownership remains explicit; secrets still use framed pipes, not argv/environment inheritance.
- awaitExec:102–125 polls only Child's owned err_pipe, with <=10ms waits and remaining time from the original pre-spawn Timer. It calls checkControls before polling, before waitForSpawn and after it. No memory probe runs before exec acknowledgement and no logical deadline is refreshed. Kernel CLOEXEC acknowledgement or the atomic typed child-error record is consumed only when readable/HUP. The first RSS check is at55/126–128, after the handshake.
- Typed exec errors stay typed: waitForSpawn's original error is returned, while its cached child.term is cleared so owned cleanup can reap normally. The actual Zig0.15.2 Child implementation stores a spawn error in term and otherwise returns before waitpid/stdio cleanup; ignoring that detail would leak ownership.
- retire:63–72 is idempotent, sends SIGKILL, then explicitly consumes waitForSpawn and clears term on any stored exec failure before normal wait. This also closes the reviewer-raised variant where cancellation/deadline happens before an already-failed exec's error pipe has been consumed. PID ownership stays held until wait; no stale PID reuse occurs through an unreaped child. Existing Session deinit/pipe/library cleanup remains paired.
- All post-exec exchange checks retain the original input/output bounds, RSS enforcement and cancellation/deadline errors. No retry, signing, prover, protocol or sandbox feature expansion was introduced by this Session change.

Owner evidence inspected on matching source:

| Check | Result |
| --- | ---: |
| New focused Linux Debug cases |3/3 |
| New focused Linux ReleaseSafe cases |3/3 |
| New focused Linux ReleaseFast cases |3/3 |
| Nonroot Linux actual SDK ReleaseSafe root |75/75, zero skips |

The permanent success regression touches256MiB in the parent and runs20 real Python workers with3000 public argv entries under48MiB, requiring an actual framed echo from each executed image. A separate100-iteration repro passes after the same fix. The FD/zombie regression runs20 FileNotFound plus20 AccessDenied spawns, then actual already-failed execs whose error pipes are left unread before cancellation/deadline; Linux /proc FD count and child list are exactly equal before/after. The pending-acknowledgement test deliberately holds a synthetic pipe open and proves original100ms deadline and asynchronous cancel remain bounded, then closes/retires its real owned fixture child.

Existing75-case root still exercises post-exec over-RSS rejection, frame bounds, absolute/partial-output timeout, actual SDK authorization/local proving, public-key derivation and denied loopback sandbox behavior. These owner executions are distinct from this independent code/log readback. Linux /proc leak assertions are Linux-specific; macOS/global/image acceptance remains Parent-owned. This review records compatibility hashes for aleo_vm_worker/root imports without claiming a separate broad security audit of their unrelated contents.

Full source hash maps, immutable raw logs and original/positive reproducer are packed in the accompanying independent artifact manifest. SHA256 chunks concatenate in order. Canonical image build and global/platform gates remain separate.
