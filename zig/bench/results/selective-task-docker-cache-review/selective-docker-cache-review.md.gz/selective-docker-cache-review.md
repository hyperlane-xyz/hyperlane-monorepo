# Selective task Docker cache review

Read-only finding: exact cache-ID filtering exists, but no deletion is currently eligible. Local Docker Buildx v0.37.2, BuildKit v0.33.1, explicit orbstack builder. Current thirteen cache records all report Reclaimable=false; this yields zero current reclaim capacity, not a multi-GiB space promise. No prune, image/container/history deletion, or Docker mutation was executed.

## Mechanism verified

Official Buildx prune documentation defines id equality selectors and AND composition. The du command accepts the same filters. The local read-only query for exact ID fvn16kmr8vrm5djh2llhqqf3q returns precisely that record; a nonexistent ID returns nothing. Adding shared=false and inuse=false to the real ID returns nothing while it remains unreclaimable.

A future authorized action can target one verified record at a time, with exact id equality, type=regular, shared=false, and inuse=false filters. Never select by time or description alone; do not use recursive parents filters, global size/free-space policies, --all, system prune, or broad builder prune. Multiple filter flags are ANDed, so several IDs must not be treated as an OR list by repeating id filters. No prune command has been run as a dry run.

## Ownership and preservation gates

Task-local command metadata binds cwd=/Users/pbio/work/ziggy, Dockerfile=zig/Dockerfile, named targets, build arguments and task tags to specific build refs. Successful build-base ref dcx3whqczj87sl09ztjvlf5c3 matches buildbase-metadata.json, its image digest/tag and source-repository revision; history inspect accepts the short build ID, not the full builder/node/ref spelling emitted by history ls. Runtime-core ref leir3g14chzcnjiffz1gzfqin is failed, not acceptance of a successful runtime/SDK image.

Build history ownership is not automatically cache-record ownership. A record description that resembles a RUN instruction, a recent timestamp, Shared=false, or placement under this builder does not by itself establish exclusivity. Shared=false describes resource sharing, not which human/project used it. A future whitelist must correlate exact compiler-stage records with this task's successful solve/export metadata and parent graph, exclude shared base images/downloads/Cargo mounts, and verify that no unrelated build uses those records. Current evidence does not authorize deleting any of the thirteen IDs.

Keep the successful final runtime/core/SDK images and their immutable digests, exported role/native artifacts, manifests/licenses, actual runtime-loader closure and acceptance evidence. The existing build-base debug container is actively needed for diagnosis and is outside this cleanup scope. Build cache records required by images/builders remain protected: Docker documents that Reclaimable=false cannot be removed even with --all; pruning shared records may remove only cache metadata while image layer storage stays allocated.

After all task builds, tests and exports have successfully joined, re-enumerate exact records. Any eventual cleanup needs before/after image and exported artifact hashes plus existing task/unrelated-image inventory preservation. Never delete Tollkeeper images/builds, other project caches, shared Docker state, or user-global caches to reach the floor.

## Capacity qualification

The old native-db compiler exec record is described as about1.133GB, but it is currently in use/unreclaimable and cannot be counted. New successful SDK intermediate records may change the inventory later. Docker logical cache sizes are not guaranteed macOS host-space recovery through OrbStack's VM storage. Require observed host df free space of at least40GiB after any independently authorized operation; no silent floor relaxation or broad purge is implied by this mechanism.

Exact read-only CLI output and references: /tmp/ziggy-selective-docker-cache-review.json.

Sources: [Buildx prune filters](https://docs.docker.com/reference/cli/docker/buildx/prune/), [Buildx du status semantics](https://docs.docker.com/reference/cli/docker/buildx/du/), [Build history metadata](https://docs.docker.com/reference/cli/docker/buildx/history/inspect/).
