# EVM / Sealevel sequential fallback budget variant

Read-only static audit; no Source/test edits, builds, SDK operations, runtime requests or benchmark measurements. Snapshot hashes: /tmp/ziggy-evm-svm-pool-budget-source.json.

## P2: ordinary EVM and Sealevel Resources retain the same physical/session deadline conflation

Trigger: Resources owns a normal Pool (not direct_native_transport or an injected exchange), with at least two configured endpoints, sequential fallback and no hedge. EndpointA's relevant RPC stalls for the full physical20s while the real operation/replay owner has120s remaining; endpointB can answer. No unrelated completed errors/probes change this Pool's priority order.

- agents/chain_source.zig143–156 creates Sealevel fallback with attempt_timeout_ms=null and explicitly rebuilds EVM fallback with null cap when no hedge is configured. settings/root.zig223–235 defaults fallback hedge delay to null.
- chain_source184 opts ReadReplay.use_owner_timeout in only for Cosmos. EVM/SVM therefore use Replay.fetch timeout=min(options.timeout_ms, ownerRemaining), net/read_replay.zig182–189:20s rather than120s. The direct exchange similarly forwards options.timeout_ms unchanged at chain_source319–322/187, ignoring an otherwise live Resources.rpc_deadline_ns/HTTP owner for this Pool path. Factory's new HTTP guard does not mediate native Multi/Pool exchange.
- evm/pool.zig642 sets the entire session deadline to start+timeout. startPeer1555–1559 has no physical cap unless attempt_timeout_ms or an applicable hedge is set, soA's transfer consumes that entire remaining session deadline.
- Pool.run779 expires the session BEFORE native.poll. curl_multi.pending181 expires the native transfer at the same deadline. Pool.finish1791–1815 calls this aggregate expiry cancellation and cancels peers. When the completion drains, Pool.complete833–836 sees an already-finished session and returns after reportUpstream(cancelled=true); dispatchOutcome/recordOutcomeFailure/failed_count/demotion are not reached.
- progressFallback1441 cannot submitB once the session has finished. The next call copies the same priorities, so it startsA again. Probes are only started from completed dispatchOutcome paths (Pool916–940/1021 onward), not a periodic autonomous health loop. A sequence consisting only of these aggregate expiries does not ageA out. Reclassifying the completed outer20s session as UpstreamReadTimeout in Replay does not reopen that finished Pool session or rotate its priority.

At full native-Multi deadline expiry this is deterministic: no budget remains to submitB. A platform timeout arriving slightly before the Pool's millisecond boundary can at most leave a tiny residual budget, not a separate physical timeout forB. This report does not claim that B is impossible under every possible independent concurrent priority change; the isolated persistent-primary trigger is sufficient to wedge normal indexing/reads indefinitely.

## Rust Source supports another provider, not a whole-logical20s deadline

Ethereum:
- rpc_clients/trait_builder.rs45 defines HTTP_CLIENT_TIMEOUT=60s; build_http_provider/get_reqwest_client421–440 builds a per-URL reqwest client with that request timeout.
- trait_builder160–179 adds every configured HTTP fallback URL.
- fallback.rs222–241 chooses ordinary sequential fallback without hedging; fallback_serialized608–651 iterates every priority and continues for retryable errors. provider_request720–748 sends to exactly one provider. rpc_clients/mod.rs60–62 classifies ReqwestError, including physical timeout, as retryable.
- ThusA may expire after60s andB is attempted in that same logical call (a stale-height probe can add separately bounded work). There is no whole logical20s deadline in this Source path. Do not claim Rust's physical timeout is20/30s.

Sealevel:
- rpc/fallback.rs242–265 builds one SealevelRpcClient per configured URL and wraps all in core FallbackProvider. Ordinary reads such as get_slot use fallback_provider.call at443–459.
- metric/prometheus_sender.rs48–55 sets per-HTTP timeout from SEALEVEL_RPC_CLIENT_ELEVATED_TIMEOUT_SECONDS, default30s.
- core rpc_clients/fallback.rs35 defines per-provider call timeout30s. call_provider179–205 wraps that provider request+success probe, turns timeout into ordinary error, and records provider failure. call_with_retry_predicate380–402 then visits the next priority. The enclosing loop does not share a whole20s limit across all peers.

This is the same confirmed Cosmos producer-policy variant, rather than an intentional Source whole-request timeout policy. Raw Pool defaults alone are not the defect: Resources currently supplies a physical20s value as the entire sequential-fallback logical session budget.

## Minimal producer opt-in, parent-owned (not implemented by this audit)

After the final Pool strategy is selected, use exactly:

    const sequential_fallback = strategy == .fallback and strategy.fallback.hedge == null;

For that branch only:
1. Set strategy.fallback.attempt_timeout_ms=options.request_timeout_ms (retain physical20s).
2. Set ReadReplay.Config.use_owner_timeout=true so its actual retained absolute owner budget spans peer attempts. Keep request/cancel/bounds identity and final owner-limited control behavior.
3. For direct Resources exchange, use the existing Resources-context absolute budget path (currently named cosmosExchange/cosmosRpcBudget), intersecting the session budget with actual rpc_deadline_ns and HTTP RPC owner, and rechecking controls after the result. Rename it to the shared sequential-fallback role rather than add a compatibility alias.
4. Apply the existing borrowed-Pool cap/strategy compatibility check to these opted-in EVM/SVM consumers as well; a borrowed uncapped or hedged Pool must not silently inherit owner-session mode.

Raw Pool defaults remain unchanged. Strategy.single, quorum, explicitly hedged fallback, direct_native_transport, injected exchanges and validator chain-vote policy retain existing behavior. A fallback with one configured endpoint remains a fallback strategy, not .single; restricting the new EVM/SVM activation to urls.len>1 is possible for the smallest availability slice, but the simple sequential_fallback condition also preserves Source's existing bounded retry rounds for that fallback case. No physical timeout reduction, new user knob, worker or Pool is needed.

Required focused proof after parent integration: actual Resources EVM and Sealevel direct/cooperative20sA→healthyB with actual120s owner; short/clamped/equal/expired owner and cancel stay control; healthy peers retain request metadata; borrowed old/null cap refused; unchanged single/quorum/hedged strategy tests. Existing Cosmos actual Resources test machinery can be extended without a new SDK build.

## Explicit hedge configuration qualification

The requested hedge==null condition is configuration-level scope. An explicitly configured hedge does not hedge every method: Native progressFallback1425–1428 uses a sequential branch for non-allowlisted/non-immutable reads, and its startPeer1559 only applies hedge.attempt_timeout_ms to hedgeable requests. Source request233–239 similarly routes those requests to fallback_serialized. Therefore those request-level sequential methods can share the same budget conflation even when hedge configuration is present. This audit disclosed that variant to the parent; it did not broaden or edit hedge policy. Fully closing it while preserving configured immutable hedge timing would require request-aware session-budget selection, not blindly applying a20s global attempt cap to all configured hedge sessions.
