# General fallback owner recovery — final Source release

Source is frozen. Owned writes: evm/pool.zig and provider.zig; sealevel/provider.zig; relayer/evm_source.zig; agents/origin_signer_source.zig; agents/scraper/receipts_{evm,cosmos,sealevel}.zig; agents/relayer/{rpc_budget,public_relay}.zig; NEW rpc_fallback_owner_{testing,tests}.zig. Ten production files plus two new test files. Parent owns chain_source integration and permanent imports; protocol owns the separate HTTP/signing correction. net/read_replay production is unchanged.

## Result

Normal Resources fallback now gives each request-level sequential endpoint its configured physical limit (default20s) while the logical operation/retained replay owner supplies the aggregate budget (default120s). Explicit hedge delay and hedgeable-request attempt limits retain authority: configured30s is not min-clamped to ordinary20s. Non-hedgeable methods on that same Pool use sequential20s. No hedge is enabled by this correction.

Provider.Options.owner_deadline_ns is optional, value-owned, absolute monotonic, and DIRECT-exchange-only. Parent's direct fallback exchange intersects it with Resources.rpc_deadline_ns, HTTP owner and the bounded per-call ceiling; controls are checked before/after and late returned bytes are freed on failure. Actual shorter client-only scopes publish their fixed deadlines and restore saved state. Cooperative ReadReplay retains its existing absolute started/max_attempt/cancel lifetime, rather than using transient direct callback metadata. EVM metadata read forks select owner-budget replay for capped fallback Pools and clear inherited direct-only deadline metadata.

Raw Pool null-cap defaults, single/quorum policy, direct-native chain votes, parser/revert/method classification and raw request identity remain unchanged. No new production allocations, worker or Pool.

## Actual timeout-writer audit

| Actual scope | Existing clock | New binding |
| --- | --- | --- |
| SVM Client.call | Client.deadline_ns | Earliest inherited/current Options owner deadline, saved Options restored |
| EVM/Cosmos/SVM receipt helpers | Supplied absolute receipt deadline | Options earliest deadline; existing timeout clamps/restores retained |
| EVM/Cosmos origin signer lookup | Existing UTC-budget→monotonic conversion | Options earliest actual fetch deadline; SVM uses Client.call |
| Protected estimate | Existing relative Scope timer | Fixed absolute deadline sampled before timer start; per-call bounded Options; original transport restored |
| Public relay extraction | Existing timer started before admission lock | Fixed absolute deadline includes lock wait; caller Options restored |
| EVM metadata child | Fresh retained read owner | Capped-fallback owner mode selected; direct-only parent deadline cleared |

All production RpcClient.Options.timeout_ms writers found by rg are deadline clamps covered above. Provider native-cache remaining-budget calculations and validator test timeout overrides use direct-native paths, outside the normal Resources Pool opt-in. No additional actual physical-only override path was found that would be silently ignored by the immutable producer cap. HTTP, worker/prover and cloud timeout fields are different boundaries and were not changed here.

## Recorded tests

| Root | Passed | Failed | Skipped |
| --- | ---: | ---: | ---: |
| New fallback owner root | 15 | 0 | 0 |
| Existing native Pool | 86 | 0 | 0 |
| Producer/header/replay focused | 37 | 0 | 0 |
| Receipt aggregate | 367 | 0 | 9 |
| Origin HTTP/native | 19 | 0 | 1 |
| Public relay aggregate | 428 | 0 | 10 |
| Protected RPC budget root | 55 | 0 | 0 |

The new root has nine substantive declarations and six import/root smoke declarations. Its live matrix uses actual Resources.open and production RPC clients: direct/cooperative default EVM, SVM and non-hedgeable eth_call under configured hedging. Each first endpoint accepts the request and stalls for the full configured20s before healthy B answers. The immutable hedge case configures30s and delays B's reply21s, proving that generic20s did not replace30s. Exact underlying A/B request bodies/IDs are checked.

Actual direct Options-only Clock and retained replay clamp/expiry, precancel and accepted-request cancellation cases keep sequential B uncalled. Cooperative cases deliberately carry expired DIRECT-only metadata and still retain their own valid owner. Additional cases cover metadata-fork configuration/lifetime, real short protected estimate Clock and restoration, structured nonretryable eth_call envelope/bytes without B, and unchanged single/quorum/independent-native vote construction.

All seven commands exit0. Fourteen selected Sources match before/after all seven runs and the archived captures. These are separate roots sharing imports, not a unique project-wide total. Origin's one optional HTTP2 fixture skip and receipt/public optional environment-dependent skips remain explicit; their optional coverage is not inferred. Existing allocator/identity/cancellation regressions pass. Native sessions, bytes and existing child/Pool lifetimes remain owned by their original mechanisms.

## Evidence and limits

Exact commands/environment and before/after selected hashes: /tmp/ziggy-rpc-fallback-owner-final-{commands,result}.json. Raw per-root logs: /tmp/ziggy-rpc-fallback-owner-final-*.log. Historical9/14 stages remain separate. Durable archive: zig/bench/results/rpc-fallback-owner-recovery/{manifest.json,commands.json.gz,result.json.gz,*log.gz,source-status.json,sources/}. Current Source bytes are archived only after matching all14 recorded hashes.

Independent read-only review: /tmp/ziggy-rpc-fallback-independent-review.md and zig/bench/results/rpc-fallback-independent-review/. Reviewer recalculated all14 current/before/after hashes, inspected actual Source paths and seven accepted logs, found no unresolved scoped blocker, and ran no builds/tests/Source edits.

No SDK/Rust/C rebuild, role, Docker image, production endpoint or benchmark run. Full native/SDK/global Safe/Fast and final emitted artifact acceptance belongs to Parent and remains separate. Actual20/30-second cases are functional liveness proofs, not CPU/RSS/throughput measurements. No performance ratios or whole-agent speedup claim follows from them.
