# Credential allocation portability independent review

Status: scoped read-only signoff. No blocker found in the four-line test-only change at agents/credentials.zig:524. No production edit or fixture construction/lease work is removed. Root owns final exact-source Linux/macOS Safe/Fast matrix acceptance.

Original Linux evidence: /tmp/ziggy-container-acceptance/root-credentials-focused.log reports NondeterministicMemoryUsage from std.testing.checkAllAllocationFailures. Isolation5/5 passed, while combined repeat evidence showed17 allocations/7792 successful resize operations in one run versus19 allocations/1 successful resize in later runs. The settings arena can remap/grow differently across address layouts, so allocation indexes were not stable despite equivalent business work.

The correction wraps std.testing.allocator in a backing std.testing.FailingAllocator with resize_fail_index=0, then retains the original outer checkAllAllocationFailures over allocatorManager. Read the actual Zig0.15.2 FailingAllocator implementation: resize/remap refuse at the configured index without advancing that index. Thus every growth request consistently falls back to a fresh allocation. No backing allocation failure index is imposed; the outer wrapper still injects and checks every constructor/lease allocation failure.

allocatorManager still executes complete fixtureSettings parsing, signer/syncer configuration, explicit environment creation, HTTP owner construction, Manager.init, lease, and all existing deferred cleanup. The change stabilizes the intended OOM cleanup sweep, including settings construction; it does not replace the tested body with a smaller isolated Manager-only fixture or remove an OOM branch.

Owner corrected Debug evidence: /tmp/ziggy-container-acceptance/root-credentials-fixed-debug.log passes all12 Manager/import-root cases. Read-only code/evidence review required no separate credential build. The corrected test also passed transitively in this reviewer's macOS full CCIP Safe/Fast runs; the first Fast run's only failure was an unrelated gRPC fixture counter accumulated by sharing one server across binaries, and is not credential acceptance evidence for the full suite.

Qualification: refusing resize/remap makes allocation-failure injection deterministic; this test does not claim coverage of successful OS in-place remapping. That is an allocator implementation concern separate from Manager ownership/OOM cleanup. Root's final Linux Safe/Fast and macOS/native checks remain independent required gates.

Current credentials.zig SHA256 chunks, concatenated in order:

- d1ac8106a37e80158d44e51d1f5a486b
- 0960eed100fc0f55651fcaa454a104b4
