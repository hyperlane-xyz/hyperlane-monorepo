# Independent fallback owner review

Accepted scoped read-only review. No unresolved blocker found. All14 final owner Source/test hashes matched current files after explicit Source freeze. No reviewer Source/test edits, tests, builds, workloads, native-library rebuilds, or benchmark timings. Parent's final global acceptance remains separate.

## Reviewed behavior

- `agents/chain_source.zig:93–99,149–194,331–355`: producer opt-in applies to fallback Ethereum/SVM/Tendermint clients. Direct fallback receives the finite read-attempt budget and intersects Resources, HTTP and explicit caller monotonic deadlines. Caller and owner cancellation are checked before/after the Pool call; post-result errors free returned bytes. Physical endpoint limits remain independent of the session budget. Borrowed Pools must match protocol/endpoints and producer physical cap. Raw direct-native votes and injected exchanges retain their previous paths.
- `evm/provider.zig:82–85`: `owner_deadline_ns` is direct-exchange authority. Native/std clients and cooperative replay do not silently reinterpret this field as their retained logical deadline.
- `evm/pool.zig:21–23,1555–1574`: optional physical cap defaults null, preserving raw Pool policy. Fallback requests use the configured immutable-read hedge timeout when hedgeable, otherwise the producer sequential cap. Thus configured30-second immutable hedges remain30 seconds while ordinary sequential requests use20 seconds; single/quorum dispatch is unchanged. Each physical request uses remaining session time and the Pool-owned cancellation token.
- `net/read_replay.zig:37–39,47–110,181–188`: retained-owner opt-in requires a separately bounded fallback Pool. The logical120-second attempt starts once, survives PendingReadIo and explicit section commits, and never refreshes on callback resume. Cancellation pointers are cleared at endPass; reset/deinit cancels owned handles and releases cached-byte reservations. The opt-in selects remaining retained time rather than a transient20-second callback timeout. Genuine logical expiry remains a control failure.
- `relayer/evm_source.zig:31–82`: async metadata forks allocate independent clients/replay journals, replace inherited direct exchanges, and clear only the direct callback clock. The fork borrows the existing Pool and bounded byte budget; it uses the retained job's stable child cancellation token. Failure unwind releases replay/origin sessions/client; normal teardown cancels replay before client destruction. Existing role shutdown joins the metadata executor before destroying destination resources/Pool, so the new option creates no Pool lifetime or stack exchange capture.
- `agents/origin_signer_source.zig:68–93,126–173`: caller UTC budget converts once to a remaining monotonic deadline after canonical provenance work. Resources cancellation and client options restore on all returns/errors. Ethereum and Cosmos direct clients intersect existing owner deadlines; SVM receives the exclusive client's job deadline and restores it. The actual origin-owner path remains serialized.
- `agents/scraper/receipts_evm.zig:44–83`, `receipts_cosmos.zig:157–180`, `receipts_sealevel.zig:77–107`: per-job absolute deadlines bind direct exchanges while existing physical/connect limits only shrink. Full client options restore with defer. Pair/multi-RPC receipt work consumes one deadline; returned responses and decoded ownership keep their existing error cleanup.
- `sealevel/provider.zig:145–163`: each exclusive client call intersects existing direct owner authority with its actual job deadline and restores options. It checks genuine job expiry after the response. Cooperative replay continues to own its retained logical budget; no ephemeral caller timeout replaces it.
- `agents/relayer/rpc_budget.zig:11–44`: protected estimates capture one fixed absolute deadline and timer, wrap the original exclusive direct exchange, pass the earlier caller deadline, and restore the complete transport/options on exit. The wrapper remains stack-local only through a synchronous sequence and is explicitly not forked.
- `agents/relayer/public_relay.zig:43–66,74–101`: extraction starts its clock before gate acquisition, uses the same fixed deadline for chain validation/receipt extraction, and restores client options and cancellation after completion/errors. Remaining-budget recalculation never grants a fresh timeout per RPC.

The reviewed delta does not change raw Pool defaults, single/quorum endpoint policy, direct independent validator votes, immutable hedge timing, or the shared remote signer capability boundary accepted separately.

## Owner evidence inspected

`/tmp/ziggy-rpc-fallback-owner-final-result.json` reports seven exit-zero roots, with unchanged before/after14-file source maps. Reviewer independently recalculated every current hash after freeze. Exact owner commands/environment are in `/tmp/ziggy-rpc-fallback-owner-final-commands.json`.

| Owner verification | Passed | Skipped |
|---|---:|---:|
| Actual fallback owner matrix |15|0|
| Pool regressions |86|0|
| Producer regressions |37|0|
| Receipt regressions |367|9|
| Origin signer regressions |19|1|
| Public relay regressions |428|10|
| Protected estimator regressions |55|0|

The focused matrix uses real native endpoint stalls: live120-second owner permits healthy fallback after a production20-second physical timeout; configured immutable hedges retain30 seconds; non-hedgeable eth_call remains sequential20 seconds. It also covers direct caller-only short/expired clocks, retained replay expiry, pre-cancel/in-flight cancellation, metadata fork ownership, protected short-clock restoration, nonretryable revert envelope preservation and single/quorum/direct-vote opt-out. Existing skipped optional integrations are not presented as executed.

## Limits

This is Source readback plus inspection of the owner's accepted test evidence, not an independent repeat execution. No global source-complete, cold SDK, Linux/container, benchmark, live production, or final PR approval claim. Full unabridged hash maps and accepted owner artifacts are retained as lossless gzip in the independent artifact directory.
