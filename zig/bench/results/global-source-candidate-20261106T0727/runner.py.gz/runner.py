import argparse, datetime, hashlib, json, os, pathlib, subprocess, time

ROOT = pathlib.Path('/Users/pbio/work/ziggy')
ZIG = '/tmp/ziggy-toolchain/zig-aarch64-macos-0.15.2/zig'
SDK = '/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk'
OUTPUT = ROOT / 'zig/bench/results/global-source-checks-20261106'

def chunks(data):
    value = hashlib.sha256(data).hexdigest()
    return [value[:32], value[32:]]

def sources():
    result = {}
    for base in ('zig/src', 'zig/tools', 'zig/integration'):
        for directory, children, files in os.walk(ROOT / base):
            children[:] = sorted(p for p in children if p not in {'target', '.cache', '.deps', '__pycache__', 'node_modules'})
            for name in sorted(files):
                path = pathlib.Path(directory) / name
                if path.suffix in {'.zig', '.rs', '.py', '.c', '.h', '.toml', '.gz'}:
                    result[str(path.relative_to(ROOT))] = chunks(path.read_bytes())
    for name in ('zig/build.zig', 'zig/build.zig.zon', 'zig/Dockerfile', '.github/workflows/zig-agents.yml'):
        path = ROOT / name
        if path.exists():
            result[name] = chunks(path.read_bytes())
    return result

env = dict(os.environ)
explicit = {
    'PYTHONDONTWRITEBYTECODE': '1',
    'ZIG': ZIG,
    'HYPERLANE_ZIG_SDKROOT': SDK,
    'ZIGGY_TXID_ORACLE': str(ROOT / 'zig/bench/results/disk-preparation-20261106/rocks-helper-functional/ziggy-rocks-oracle'),
    'HYPERLANE_CURL_LIBRARY': '/usr/lib/libcurl.4.dylib',
    'HYPERLANE_CLOUD_CURL_LIBRARY': '/usr/lib/libcurl.4.dylib',
    'HYPERLANE_LIBCRYPTO_LIBRARY': '/opt/homebrew/opt/openssl@3/lib/libcrypto.3.dylib',
    'HYPERLANE_STARKNET_CRYPTO_LIBRARY': str(ROOT / 'zig/src/starknet/native-crypto/target/release/libziggy_starknet_crypto.dylib'),
    'HYPERLANE_ALEO_CRYPTO_LIBRARY': str(ROOT / 'zig/src/aleo/native-crypto/target/release/libziggy_aleo_crypto.dylib'),
    'HYPERLANE_ALEO_VM_LIBRARY': str(ROOT / 'zig/src/aleo/native-vm/target/release/libziggy_aleo_vm.dylib'),
    'HYPERLANE_ALEO_VM_WORKER': '/tmp/ziggy-aleo-vm-worker',
    'HYPERLANE_ALEO_PARAMETER_HOME': '/tmp/ziggy-aleo-parameters',
    'ZIGGY_REGEX_LIBRARY': str(ROOT / 'zig/src/ops/regex-native/target/release/libziggy_regex.dylib'),
    'HYPERLANE_REGEX_LIBRARY': str(ROOT / 'zig/src/ops/regex-native/target/release/libziggy_regex.dylib'),
}
env.update(explicit)
base = [ZIG, 'test', '-O', 'ReleaseSafe', '-lc', '--sysroot', SDK, '-L/usr/lib']
native = json.loads((ROOT / 'zig/bench/results/native-db-test-command.json').read_text())
commands = [
    ('default', ['python3', 'zig/tools/native_http_tests.py', '--mode', 'ReleaseSafe', '--library', '/usr/lib/libcurl.4.dylib', '--libcrypto', '/opt/homebrew/opt/openssl@3/lib/libcrypto.3.dylib']),
    ('native-db', native),
    ('postgres', ['python3', 'zig/integration/postgres.py', '--compiler', ZIG, '--sdk-root', SDK, '--libpq-library', '/opt/homebrew/opt/libpq/lib/libpq.dylib', '--image', 'postgres:16.15', '--output', '__POSTGRES_OUTPUT__']),
    ('roles-build', ['python3', 'zig/tools/zig.py', '--compiler', ZIG, '--sdk-root', SDK, 'build', 'validator', 'relayer', 'scraper', '-Doptimize=ReleaseSafe', '-Dnative-db-libs=' + ','.join(v.strip() for v in pathlib.Path('/tmp/ziggy-rocks-final-libs.txt').read_text().replace('\n', ',').split(',') if v.strip()), '-Dlibpq-library=/opt/homebrew/opt/libpq/lib/libpq.dylib', '--prefix', '__ROLE_PREFIX__', '-j2']),
    ('validator-help', ['__VALIDATOR__', '--help']),
    ('relayer-help', ['__RELAYER__', '--help']),
    ('scraper-help', ['__SCRAPER__', '--help']),
    ('rpc-producers', base + ['zig/src/rpc_producer_tests.zig']),
    ('operator-regex', base + ['zig/src/ops_tests.zig']),
    ('ws-wss', base + ['zig/src/websocket_delegated_tests.zig']),
    ('socket-owner', base + ['zig/src/socket_owner_tests.zig']),
]

def main():
    global OUTPUT
    parser = argparse.ArgumentParser()
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--mode', choices=['ReleaseSafe', 'ReleaseFast'], default='ReleaseSafe')
    parser.add_argument('--matrix-cache-root', type=pathlib.Path, help='Use exact freshly rebuilt/preserved matrix SDKs and the matching mode worker')
    parser.add_argument('--only', choices=[name for name, _ in commands])
    parser.add_argument('--output', type=pathlib.Path, default=OUTPUT)
    args = parser.parse_args()
    OUTPUT = args.output.resolve()
    native_archive_paths = [pathlib.Path(value) for value in native if value.endswith('.a')]
    if args.matrix_cache_root:
        matrix = args.matrix_cache_root.resolve(strict=True)
        overrides = {
            'HYPERLANE_STARKNET_CRYPTO_LIBRARY': matrix / 'sdk-starknet/release/libziggy_starknet_crypto.dylib',
            'HYPERLANE_ALEO_CRYPTO_LIBRARY': matrix / 'sdk-aleo-crypto/release/libziggy_aleo_crypto.dylib',
            'HYPERLANE_ALEO_VM_LIBRARY': matrix / 'sdk-aleo-vm/release/libziggy_aleo_vm.dylib',
            'ZIGGY_REGEX_LIBRARY': matrix / 'sdk-regex/release/libziggy_regex.dylib',
            'HYPERLANE_REGEX_LIBRARY': matrix / 'sdk-regex/release/libziggy_regex.dylib',
            'HYPERLANE_ALEO_VM_WORKER': matrix / ('zig-out-' + args.mode) / 'bin/hyperlane-aleo-vm-worker',
        }
        for name, path in overrides.items():
            if not path.is_file():
                raise RuntimeError('Missing actual matrix runtime artifact: ' + str(path))
            explicit[name] = str(path)
        env.update(explicit)
        native_archive_paths = [matrix / 'native-sdk' / path.name for path in native_archive_paths]
        if len(native_archive_paths) != 7 or not all(path.is_file() for path in native_archive_paths):
            raise RuntimeError('Missing actual preserved matrix native archives')
    replacements = {'__POSTGRES_OUTPUT__': str(OUTPUT / 'postgres'), '__ROLE_PREFIX__': str(OUTPUT / 'roles'), **{'__' + role.upper() + '__': str(OUTPUT / 'roles/bin' / role) for role in ('validator', 'relayer', 'scraper')}}
    selected = [(name, [replacements.get(value, value) for value in command]) for name, command in commands if not args.only or args.only == name]
    if args.matrix_cache_root:
        selected = [(name, [value.replace(str(ROOT / 'zig/native/rocks/out-final'), str(matrix / 'native-sdk')) for value in command]) for name, command in selected]
    selected = [(name, [args.mode if value == 'ReleaseSafe' else value.replace('-Doptimize=ReleaseSafe', '-Doptimize=' + args.mode) for value in command]) for name, command in selected]
    if not args.execute:
        print(json.dumps(selected, indent=2))
        return
    OUTPUT.mkdir(parents=True, exist_ok=True)
    before = sources()
    record = {'scope': 'Functional correctness checks, not benchmark timings or final build matrix', 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'environment': explicit, 'requested_native_mode': args.mode, 'postgres_suite_mode': 'ReleaseSafe (integration helper explicit fixed mode)', 'runtime_artifacts': [{'environment_name': name, 'path': path, 'bytes': pathlib.Path(path).stat().st_size, 'sha256_chunks': chunks(pathlib.Path(path).read_bytes())} for name, path in explicit.items() if name.endswith('_LIBRARY') or name in {'HYPERLANE_ALEO_VM_WORKER', 'ZIGGY_TXID_ORACLE'} if pathlib.Path(path).is_file()], 'native_archives': [{'path': str(path), 'bytes': path.stat().st_size, 'sha256_chunks': chunks(path.read_bytes())} for path in native_archive_paths], 'source_before': before, 'checks': []}
    manifest = OUTPUT / (f'{args.only or "all"}-manifest.json')
    for name, command in selected:
        log = OUTPUT / f'{name}.log'
        if log.exists():
            raise RuntimeError(f'Refusing to overwrite prior check log: {log}')
        started = time.monotonic()
        with log.open('w') as stream:
            result = subprocess.run(command, cwd=ROOT, env=env, stdout=stream, stderr=subprocess.STDOUT)
        row = {'name': name, 'command': command, 'exit_code': result.returncode, 'check_elapsed_seconds': time.monotonic() - started, 'log': str(log.relative_to(ROOT)), 'log_sha256_chunks': chunks(log.read_bytes())}
        record['checks'].append(row)
        record['role_artifacts'] = [{'role': role, 'path': str(binary.relative_to(ROOT)), 'bytes': binary.stat().st_size, 'sha256_chunks': chunks(binary.read_bytes())} for role in ('validator', 'relayer', 'scraper') if (binary := OUTPUT / 'roles/bin' / role).is_file()]
        record['source_after'] = sources()
        record['source_unchanged'] = before == record['source_after']
        manifest.write_text(json.dumps(record, indent=2) + '\n')
        print(json.dumps({key: row[key] for key in ('name', 'exit_code', 'check_elapsed_seconds')}), flush=True)
        if result.returncode:
            raise SystemExit(result.returncode)
    if not record['source_unchanged']:
        raise RuntimeError('Source changed during functional checks; results are diagnostic only')

if __name__ == '__main__':
    main()
