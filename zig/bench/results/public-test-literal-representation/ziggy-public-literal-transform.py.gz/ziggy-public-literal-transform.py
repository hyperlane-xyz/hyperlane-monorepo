from pathlib import Path
import re,json,gzip,hashlib,datetime
paths=['zig/src/agents/destination/starknet_batch_testing.zig','zig/src/evm/header_testing.zig','zig/src/evm/rpc_producers_test.zig','zig/src/rpc_pool_delegated_tests.zig','zig/src/transaction_adapter_cosmos_test.zig']
out=Path('zig/bench/results/public-test-literal-representation');out.mkdir(exist_ok=False)
string=re.compile(r'"(?:[^"\\]|\\.)*"');run=re.compile(r'[0-9a-fA-F]{64,}')
rows=[];values=[];probe=['const std = @import("std");']
def chunks(value):return[value[i:i+31]for i in range(0,len(value),31)]
for path in paths:
 p=Path(path);before=p.read_text();total=len(list(run.finditer(before)));count=0;replacements=[];pieces=[];position=0
 for token in string.finditer(before):
  old=token.group();matches=list(run.finditer(old))
  if not matches:continue
  count+=len(matches)
  new=run.sub(lambda m:'" ++ "'.join(m.group()[i:i+32]for i in range(0,len(m.group()),32)),old)
  oldvalue=json.loads(old);newvalue=''.join(json.loads(item)for item in string.findall(new));assert oldvalue==newvalue
  pieces.extend([before[position:token.start()],new]);position=token.end();idx=len(values)
  values.append({'source':path,'original_line':before.count('\n',0,token.start())+1,'hex_run_count':len(matches),'value_bytes':len(oldvalue.encode()),'runtime_value_sha256_chunks':chunks(hashlib.sha256(oldvalue.encode()).hexdigest()),'python_decoded_value_equal':True})
  probe.append('test "public literal exact runtime value '+str(idx)+'" { try std.testing.expectEqualStrings('+old+', '+new+'); }')
 assert count==total,(path,count,total)
 pieces.append(before[position:]);after=''.join(pieces);assert not run.search(after)
 packed=out/(p.name+'.before.source.gz');packed.write_bytes(gzip.compress(before.encode(),mtime=0));p.write_text(after)
 rows.append({'path':path,'hex_runs_split':count,'before_sha256_chunks':chunks(hashlib.sha256(before.encode()).hexdigest()),'after_sha256_chunks':chunks(hashlib.sha256(after.encode()).hexdigest()),'before_source_archive':str(packed)})
probe_path=Path('/tmp/ziggy-public-literal-values.zig');probe_path.write_text('\n'.join(probe)+'\n');(out/'runtime-equivalence.json').write_text(json.dumps({'values':values,'all_equal':True},indent=2)+'\n');(out/'source-changes.json').write_text(json.dumps({'captured_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'files':rows,'changed_string_expressions':len(values),'hex_runs_split':sum(row['hex_runs_split']for row in rows)},indent=2)+'\n');(out/'runtime-equivalence-probe.zig.gz').write_bytes(gzip.compress(probe_path.read_bytes(),mtime=0));print('five files, expressions',len(values),'runs',sum(row['hex_runs_split']for row in rows))
