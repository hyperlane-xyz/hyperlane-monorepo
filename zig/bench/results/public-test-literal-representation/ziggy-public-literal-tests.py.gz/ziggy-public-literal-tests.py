import json,pathlib,subprocess,os,time,gzip,hashlib
base=['/tmp/ziggy-toolchain/zig-aarch64-macos-0.15.2/zig','test']
flags=['-O','ReleaseSafe','-lc','--sysroot','/Library/Developer/CommandLineTools/SDKs/MacOSX15.4.sdk','-L/usr/lib']
cases={
 'runtime-values':base+['/tmp/ziggy-public-literal-values.zig']+flags,
 'batch':json.loads(pathlib.Path('zig/bench/results/starknet-nonce-proof/commands.json').read_text())['commands']['batch'],
 'headers-and-producers':base+['zig/src/rpc_producer_tests.zig']+flags+['--test-filter','RPC producers','--test-filter','typed header'],
 'pool':base+['zig/src/rpc_pool_delegated_tests.zig']+flags,
 'cosmos':base+['zig/src/transaction_adapter_tests.zig']+flags+['--test-filter','Cosmos transaction companion'],
}
env={k:v for k,v in {'HYPERLANE_CURL_LIBRARY':'/usr/lib/libcurl.4.dylib','HYPERLANE_CLOUD_CURL_LIBRARY':'/usr/lib/libcurl.4.dylib','HYPERLANE_STARKNET_CRYPTO_LIBRARY':str(pathlib.Path('zig/src/starknet/native-crypto/target/release/libziggy_starknet_crypto.dylib').resolve())}.items()}
results=[]
for name,cmd in cases.items():
 p=pathlib.Path('/tmp/ziggy-public-literal-'+name+'.log'); start=time.time()
 with p.open('wb') as f:r=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,env={**os.environ,**env})
 result={'name':name,'command':cmd,'environment':env,'exit_code':r.returncode,'elapsed_seconds':round(time.time()-start,3),'log':str(p)}
 results.append(result);pathlib.Path('/tmp/ziggy-public-literal-results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(name,r.returncode,p.read_text().splitlines()[-1:] ,flush=True)
 if r.returncode:break
