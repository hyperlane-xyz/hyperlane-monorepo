# Independent metadata fixture request-count review

Read-only conclusion: the exact 26 physical checkpoint GET assertion is not a production guarantee. The observed 24 is compatible with correct early threshold completion. No production fix is justified by this count alone; no files were edited or tests run by this reviewer.

Evidence:

- remote_checkpoints.zig:227–233 returns immediately when Collector.push yields the first quorum. finish():253–255 marks the request finished and stores session.closed=true.
- quorum.zig:51–89 verifies index, recovers each configured validator identity, groups the complete checkpoint, and returns when the first matching root reaches threshold. This test threshold is2, with signed checkpoint(domain1,index3,root2,message_id4).
- remote_checkpoints.zig:655–664 cancels remaining native HTTP/disk work once closed. progress:677–705 submits at most16 peers per scheduling pass;26 guarded eligible peers are not an all-wire-completion barrier. Native requests carry the closed token at698. curl_multi.zig:172–182 completes queued/active requests as canceled when that token becomes true, including before HTTP headers are sent.
- Guard-all is a separate prerequisite: remote_checkpoints.zig:666–675 enters read phase only after every peer reaches guarded/done. An unreadable guard at peer26 advances it to done; it must not receive checkpoint/latest reads. Exact27 guard requests per phase and the existing error diagnostic remain valid.
- agents/metadata_session.zig:136–154 caches a completed quorum and marks the entry done. Replays skip submit/poll and only clone the cached result at159–161. This supports strict no-refetch assertions without requiring all initially admitted peers to produce physical GETs.

Strong assertion shape: selected checkpoint equals the expected complete value, signature count is exactly2 with valid distinct configured signers; first successful quorum needs at least2 healthy checkpoint GETs and at most26 total. Each peer gets at most1 checkpoint GET during the retained attempt, peer26 gets0, and all parsed reads use the exact allowed object names. Latest phase waits for all eligible peers, so retain exact27 guards/26 latest requests, per-peer identity/value and failed-guard-null assertions. Builder full observation retains its distinct exact latest/metrics requirements; early quorum does not weaken full latest collection.

For cached replay, baseline physical checkpoint counts after the full latest phase or explicit cancellation/drain synchronization, then assert no checkpoint/latest/guard delta on immediate retained replay. The old snapshot immediately after early quorum can race already-admitted headers still being processed by the server; that is not a new session fetch. Per-peer at-most-once counters across the entire attempt additionally catch duplicate physical work. Do not assert that all9 deliberately stalled peers necessarily reach the wire before threshold cancellation.

Qualification: this reviews the existing production state machine and the old count assertion. Root owns fixture edits and final Linux/macOS Safe/Fast verification. A helper that ignores zero-byte preheader cancellation can be correct while still rejecting incomplete/malformed nonempty headers.

Production-source SHA256 chunks at review, concatenated in order:

- zig/src/relayer/remote_checkpoints.zig: ef1d8c83f0097216364f4aafba325574 / ecbb155f5f830b46feafbc027ce2dd8d

- zig/src/relayer/quorum.zig: 70610e3b7f37f60d809855be6134ed04 / d5aa3e9129db255775b1e8ec97b3bea6

- zig/src/agents/metadata_session.zig: d2401053d56a3cccb956a4da44291876 / f4a7119519934fbb3dc72798d0b02a71

- zig/src/net/curl_multi.zig: 861913b091245039d9c565dc46b9f433 / dda80b7346fa128edf577c68bef6486e
