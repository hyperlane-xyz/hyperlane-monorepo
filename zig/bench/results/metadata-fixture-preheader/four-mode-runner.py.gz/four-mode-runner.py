from pathlib import Path
import subprocess,json,os,hashlib,sys
root=Path('/Users/pbio/work/ziggy');out=root/'zig/bench/results/metadata-fixture-preheader';old=json.loads((out/'result.json').read_text());p=root/'zig/root-metadata-fixture-diagnostic.zig'
with p.open('x') as f:f.write('comptime { _ = @import("src/agents/metadata_session_test.zig"); }\n')
source=root/'zig/src/agents/metadata_session_test.zig';before=hashlib.sha256(source.read_bytes()).hexdigest();rows=[]
try:
 for row in old['checks']:
  name=row['system']+'-'+row['mode']+'-'+sys.argv[1]+'.log';log=out/name
  if log.exists():raise RuntimeError('Refusing overwrite')
  env=dict(os.environ,HYPERLANE_CURL_LIBRARY='/usr/lib/libcurl.4.dylib') if row['system']=='macOS' else None
  with log.open('w') as f:r=subprocess.run(row['command'],cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT)
  rows.append({**row,'exit_code':r.returncode,'log':str(log.relative_to(root))});print(json.dumps({'system':row['system'],'mode':row['mode'],'exit_code':r.returncode}),flush=True)
  if r.returncode:break
finally:
 after=hashlib.sha256(source.read_bytes()).hexdigest();p.unlink();(out/(sys.argv[1]+'-result.json')).write_text(json.dumps({'source_before_sha256_chunks':[before[:32],before[32:]],'source_after_sha256_chunks':[after[:32],after[32:]],'source_unchanged':before==after,'checks':rows},indent=2)+'\n')
