# Independent non-Starknet cold sender acceptance

Test-only slice released: **20/20 passed**, no skips, two new substantive tests.
Only new native_sender_recovery_test.zig and its focused root were written.
No production edit, role/SDK/native build, daemon, container or benchmark.

## Actual pipeline

A real Tron Factory prepares a public fixture process intent. Production Actor
staged/prepared APIs persist Ready in RocksDB; the actual Driver performs current
policy/quote/allowance/sender gates before the real std LocalSigner callback.
After Ready and after Signed persistence, tests close/reopen the database,
recreate Factory/Actor and construct a fresh origin signer Owner with an empty
cache. Origin lookup uses actual Source.initProvenance/native Store metadata and
an EVM RpcClient exchange fixture. No fake Lookup or prepopulated cache is used.
The Driver SignerGate calls the runtime owner's test-only NativeTests wrapper,
which forwards directly to the common production Root.originSenderGate with
retained SenderState and policy. Root context here is a narrow initialized gate
owner, not a complete running role. Tron signing and wire codecs use Zig std;
no Starknet/Aleo/Cosmos SDK is needed.

## Ready recovery

A new address rule plus origin peer failure causes Source's30-second delay and
zero executable key calls/broadcasts. Boundary-minus1 remains idle without a
lookup. At the boundary, real origin lookup returns a denied transaction signer,
still with zero key calls. Replacing the address rule permits cached signer proof;
the real Driver/Factory prepares and signs once. No duplicate origin lookup is
needed. This catches an unconditional cached-only bypass at the recovered Ready
signing boundary.

## Signed recovery

After durable std signing, a cold cache and new address rule force initial lookup
before broadcast. The denied signer produces zero broadcasts and no second
signature. After policy permits it, the physical broadcast mock receives bytes
identical to the persisted signed record, with the same native identity and one
signer callback total. Reintroducing denial still permits a real parsed/canonical
final receipt: gas10*price10 is stored once, confirmation starts, and actual
Mailbox delivered state marks processed/removes pending without another sender
lookup, broadcast or key call. Repeated receipt observation leaves expenditure100.

## Evidence and limitations

Exact command/raw log/source hashes:
/tmp/ziggy-native-sender-recovery-{command.json,tests.log,result.json}.
The initial compile log is preserved separately; it contains only our fixture's
incorrect nowNs import, corrected to the existing receipts_evm public helper.
Formatting/diff checks pass. Runtime/Parent owns standard native-root imports.

20 includes transitive root smoke declarations; only two are new substantive
non-Starknet acceptance tests. This complements, rather than replaces, the
Starknet26/26 control/metric tests and the parent's global/default/native/PG/role
and exact final matrix SDK/binary gates. No performance claim is made.
