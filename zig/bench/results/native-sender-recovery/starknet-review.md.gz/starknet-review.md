# Independent Starknet group cold-control acceptance

New test-only slice released: **26/26 passed**, no skips, including six new
substantive tests. Actual Root/Factory/Rocks and existing Starknet crypto SDK;
no production Source edit, SDK/role build, daemon, container or benchmark.

## Cold sender blocker closure

A signed durable group is first created through real query/sign/broadcast
boundaries. The fixture then closes/reopens its DB and recreates Factory/Lane,
leaving zero Active actors. A new origin signer Owner starts with an empty cache.
Its retained per-origin Resources/RpcClient uses real Source.initProvenance with
canonical native Store dispatch metadata, explicit test RPC exchange and Source
UTC read budgets. No cached sender or synthetic lookup result is injected.

After adding a new address rule for the actual origin transaction signer:

- Initial transaction/receipt lookup occurs before any rebroadcast; the newly
  denied sender blocks the whole group's exact signed bytes. Cached reuse adds
  no origin calls, and a later unrelated address rule permits replay without
  another executable signature/nonce query/estimate.
- Ordinary peer failures retain Source30/60/120/240-second delays. Calls at each
  boundary-minus1 do not retry or broadcast; calls at the exact boundary retry.
  Only Source's fifth-failure giveup allows progress, followed by cached-only
  cooldown. The test uses injected monotonic observation time, no wall sleeps.
- Missing canonical dispatch hash performs no fabricated RPC and waits once30s
  before Source's documented proceed behavior.
- A real successful destination receipt still reconciles to durable included
  group and per-member confirmation while sender policy blocks rebroadcast.
  No sender lookup, executable signature or extra broadcast is required.

These tests close the cold restored-group cached-only bypass against the runtime
owner's common retained sender gate. Source checks now use initial lookup,
bounded retained backoff state and existing shared cache. Test owner made no
production fix.

## Submitted metric and pre-key control closure

The real Registry/relayer Adapters report exactly2 submitted events for the two
members even with zero Active actors. Both normal inclusion and durable commit
followed by NativeGroupCommitOutcomeUnknown are covered. Same-process replay,
loading restored Confirm actors and a fresh Lane epoch leave the counter at2;
they do not report0,1 or duplicate events. Signature/nonce/broadcast counts are
unchanged by this recovery.

Before executable signing, a message-domain deny rule and an actual
Control.Hub.reprocessOwner queue/drain request each abandon the complete unsigned
group and restore the untouched scalar's exact original intent. Both leave zero
broadcasts and query-only signature count1. Caller cancellation blocks signing/
broadcast and preserves the recoverable unsigned group. Thread cleanup always
cancels/joins the bounded admin caller before fixture destruction, including
error paths. This is the actual Control API route, not a fabricated manual DB
status.

## Source and evidence

Only new files:
- zig/src/starknet_group_control_native_test.zig
- zig/src/starknet_group_control_tests.zig

Runtime owner owns normal native-root test wiring and all production helpers.
Current hashes, exact command, explicit SDK/curl environment and SDK digest:
/tmp/ziggy-starknet-group-control-result.json.
Raw final log: /tmp/ziggy-starknet-group-control-tests.log.
Earlier22/22 cold and25/25 metric passes are preserved separately. Initial
compile failures are preserved as first/second/third/fourth-compile logs: they
contain the in-progress Source syntax/optional-error comparison issues and our
fixture WireResponse/wake constness corrections; no failed sample was replaced
without retention.

The final26 count includes imported root smoke test declarations; it is six new
substantive acceptance tests. No all-VM/performance claim follows. Parent still
must complete global/native/Postgres/role checks and rebuild/test final matrix
SDK/binaries before timing or full rewrite completion.
