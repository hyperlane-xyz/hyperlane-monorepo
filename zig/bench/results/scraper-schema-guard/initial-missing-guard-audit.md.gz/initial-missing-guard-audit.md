# Final bounded completeness/parity audit

Read-only source audit, 2026-11-06. Rust baseline remains unchanged. No Source edits, tests, compiler, daemons, network requests, credentials, staging or commits. The prior report at this pathname was preserved separately before replacement; its tx-ID/backpressure findings are historical and resolved below.

## Finding: P2 — scraper startup omits mandatory index/cutover validation

**Confirmed implementation blocker; high confidence.**

Rust `rust/main/agents/scraper/src/agent.rs:74–82` connects the scraper DB and calls `db.verify_frontier_indexes()` before building scrapers. `src/db/mod.rs:109–110` forwards to `rust/main/agents/scraper/migration/src/indexes.rs:178–203`. That read-only verifier requires:

1. `gas_payment_block_log` valid/ready/unique, with the exact ten-key canonical event identity and partial predicate, through `gas_payment_log_index_valid` (`indexes.rs:131–155`).
2. The three frontier indexes `delivery_frontier_unenriched`, `gas_payment_frontier_unenriched`, `gas_payment_frontier_height`, with expected table, btree method, ordered key list, no expressions/include extras, uniqueness, predicate, ready and valid status (`indexes.rs:52–72`, `206–249`).
3. No superseded `gas_payment_transaction_log`, whose transaction-scoped uniqueness rejects legitimate distinct gas rows sharing fallback positions (`indexes.rs:190–203`).

The Source comment states the reason: interrupted/mismatched frontier indexes can turn bounded near-head work into full-table scans, and the gas-payment position cutover must finish before startup. Its real PostgreSQL regression drops/replaces these indexes and verifies rejection (`indexes.rs:260–297`). This is an implemented startup contract, not a hypothetical new hardening requirement.

Native `zig/src/agents/scraper/task.zig:377–409` initializes a lazy libpq pool, shared HTTP runtime and task structures, then constructs lanes. `Lane.database` (`191–197`) acquires a lease and applies session timeouts. `zig/src/db/pool.zig:65–140` connects/reconnects and configures timeouts but performs no index validation. A search of current Zig production source found no `pg_index`, `indisvalid`, `indisready`, the required index names or equivalent verifier. The existing integration helper proves a fully migrated valid DB only; running Rust `init-db` first does not prove rejection of interrupted/mismatched schema at ordinary daemon startup.

Concrete trigger: point the configured scraper at a DB with an interrupted concurrent frontier-index build, an unexpected same-named index definition, an incomplete canonical gas-payment identity-index cutover or the obsolete transaction-scoped index still present. Rust rejects startup before scraping. Native continues into lane work: absent frontier indexes permit the scans Source refuses, while obsolete gas uniqueness can reject a valid event batch. Native gas insertion is a plain INSERT (`db/scraper_store.zig:398–435`); no claim of silent ON CONFLICT suppression is made.

**Required closure:** Source-equivalent read-only catalog verification on the actual configured scraper DB before any lane effect, preserving cancellation and one bounded DB initialization deadline. Fail closed; no automatic DROP/CREATE/REINDEX, migrations or catalog mutation. Actual disposable PostgreSQL proof must cover valid DB plus invalid/missing/wrong-definition frontier/canonical identity indexes and obsolete index presence, including daemon-construction wiring.

## Rechecked prior findings: resolved in current implementation

| Earlier gap | Current reachable implementation |
| --- | --- |
| Ordinary tx-ID companion absent | `agents/origin_tasks.zig:135–153` allocates companion only when enabled and protocol-supported, installs Store notifications and enables generic producer notifications. `agents/store.zig:239–247` notifies after canonical persistence, including replay. `agents/indexing/tx_id_companion.zig:43–172` scans durable canonical rows, validates receipt identity and persists recovered gas/tree rows independently of range cursors. |
| Failed receipt prefix monopolizes bounded queue | `agents/indexing/tx_id_queue.zig:124–160` releases admission slots into bounded deferred replay hints; explicit replay scheduling avoids unconditional repeated full-history scans. Companion retains per-row/partial persistence work and cancellation ownership. |
| Aleo emitter/index assumptions | `agents/indexing/tx_id_companion.zig:70–93` obtains concrete transaction authority and protocol position namespace; `agents/indexing/source.zig:576` uses actual authority for ordinary range validation. `agents/validator/index_source.zig` forwards through the current live endpoint rather than borrowing a retired inner context. |
| Supported native preparation cap ignored | `agents/relayer/native_driver.zig:301–306` selects exactly Source-supported Cosmos Wasm/SVM/Starknet subset; `agents/relayer_task.zig:1408–1445`, `1532–1536` count queued submit work and gate fresh preparation, while ready/signed/confirmation work drains. EVM forwards its cap to Lander (`relayer_task.zig:271`). |
| Physical timeout consumes whole first-peer budget | `agents/chain_source.zig:162–190`, `334–351` separates opted-in sequential physical caps from actual owner/session budgets. Explicit immutable-hedge attempt limits remain authoritative in Pool; direct Options owner clocks and retained replay ownership remain separate. Prior HTTP/signing-owner isolation correction is present. |
| Old ownership report's uninitialized access-list suffix | `lander/types.zig:305–313` initializes all tuples to safe empty values before any fallible member parsing. |
| Old ownership report's receipt-progress allocation entry | `lander/service.zig:114` initializes a safe map entry before fallible item allocation; the permanent allocation regression remains at `1214`. |

These are source-reachability conclusions. Earlier focused artifact counts remain bound to their own recorded snapshots; this audit did not rerun them.

## All-eight-chain implementation wiring

Actual construction was inspected rather than inferred from protocol enum variants. `agents/chain_source.zig:195–272` creates concrete protocol clients; `agents/scraper/factory.zig:26–76` binds concrete indexers and returns actual Source callbacks. Both Cosmos protocols share a client tag but select native/Wasm behavior through chain.protocol. Generic validator uses these concrete sources through `agents/validator/generic.zig:94–119`, `252`, with endpoint votes/consensus, indexing and frontier audit; Ethereum uses its dedicated role.

| Protocol | Indexing/receipt implementation | Submission/metadata implementation and supported boundary |
| --- | --- | --- |
| Ethereum | `agents/scraper/evm.zig`, `evm/indexer.zig`, `receipts_evm.zig`; dedicated origin/validator path | `agents/relayer/evm_prepare.zig`, `evm_driver.zig`, `lander/service.zig`; production factory receives batch/overrides/protected transport config. |
| Sealevel | `agents/scraper/sealevel.zig`, `receipts_sealevel.zig` | `agents/destination/sealevel.zig`, Factory payer/identity/ALT/override/oracle/submission endpoint wiring; generic metadata Source supports the implemented composite path. |
| Cosmos Wasm | `agents/scraper/cosmos.zig` native=false, `receipts_cosmos.zig` | `agents/destination/cosmos.zig` native=false; actual gas/compatibility/prefix/address configuration forwarded. |
| Cosmos Native | Same concrete index/receipt adapter native=true | Same concrete destination native=true; native query/execute behavior is selected, not an empty enum branch. |
| Starknet | `agents/scraper/starknet.zig`, `receipts_starknet.zig` | `agents/destination/starknet.zig`; `agents/relayer/native_group.zig` plus Lane grouped coordinator implement shared nonce/account transaction semantics and atomic multi-member ownership. |
| Radix | `agents/scraper/radix.zig`, `receipts_radix.zig` | `agents/destination/radix.zig`, Core/Gateway resources, manifest/signature and finality paths. |
| Aleo | `agents/scraper/aleo.zig`, `receipts_aleo.zig` with actual SDK decoder | `agents/destination/aleo.zig`, isolated VM/proof process and selected local/delegated prover; this retains counted native protocol-library dependencies. |
| Tron | `agents/scraper/tron.zig`, `receipts_tron.zig` | `agents/destination/tron.zig`, wallet/solidity/RPC endpoints, raw transaction/signing and solidified-state finality. |

Source batch parity is not inferred from generic maxBatchSize parsing: Rust's non-EVM override is Starknet (`chains/hyperlane-starknet/src/mailbox.rs:207–213`); other non-EVM mailbox implementations do not override `supports_batching`/`process_batch`. The new grouped Starknet path therefore closes the supported gap rather than requiring invented batching on all other VMs.

## Other required subsystem readback

- **Process/scheduling/health:** `service_main.zig:88–181` loads settings, creates real Registry/server, constructs all three roles plus common health jobs, binds relayer operator/public handlers and starts Supervisor. `supervise` checks preserved fatal failure reason. Supervisor's explicit stop hooks and joined workers preserve halt/drain rather than merely dropping a task future. Dedicated destination owners are a documented scheduling/resource tradeoff, not Tokio-equivalent resource behavior.
- **Configuration:** native Settings contains all current role-level fields from Rust relayer/settings, validator/settings and scraper/settings; actual consumers were checked for gas/matching rules, retries, API flags/ports/rate limits/CORS, tx-ID/IGP flags, checkpoint cache flags, local checkpoint permission, runtime denylist, WS authority, public RPC policy, lightweight/announcement mode, consensus and signing-publication bound. Per-chain max batch/cap/overrides, native fees/ALTs/identity/prover/finality are wired. No new missing current role field was established.
- **Metadata support:** Rust dispatch is `agents/relayer/src/msg/metadata/message_builder.rs:232–253`; Zig `relayer/metadata.zig` dispatch covers standard multisig, routing, aggregation, null, CCIP and SVM composite. Module IDs present in enums but rejected by Rust are not required new implementations. External SVM aggregation, Cosmos Native aggregation, Radix aggregation placeholder and non-supported CCIP protocol combinations remain Source boundaries (`hyperlane-base/src/settings/chains.rs:1380–1471`).
- **Validator:** ordinary and generic role opening, endpoint count/denominator and consensus selection, local-history authentication/frontier audit, backfill, fail-closed reorg handling, checkpoint signing/publication and announcement work are present. `validator_task.zig:102–166` selects EVM/generic and independent announcement work; generic role consumes max_sign_concurrency as bounded publications. Readiness/merkle insertions/Eigen endpoints have actual handlers. This is implementation presence, not all-chain final daemon acceptance.
- **Checkpoint/cloud/key ownership:** local/S3/GCS resources, announcement discovery, ignored/latched reorg reports, AWS/GCP/ambient credential ownership and remote signer refresh have concrete runtime consumers. Separate/shared HTTP signing boundaries reflect the recently reviewed correction; local signing does not force credential discovery. No new primitive gap found.
- **Durability:** `agents/operation.zig:235–259` uses locked current-row/status comparisons and atomic fsynced multi-key updates. Destination payload/transaction links and grouped journals remain separate persisted authority; grouped key callbacks revalidate current members. Native scraper uses database-clock leases, transactional event/head changes, confirmed-boundary guards, receipt enrichment and reconciliation. **Catalog startup validation is the confirmed exception above.**
- **Scraper lanes:** `agents/scraper/task.zig:431–438` constructs head, delivery, gas, reconciliation and optional CCR work. Configured CCR rejects non-Ethereum consistently with Source's EVM router feature. Healthy-chain scheduling is not gated by another chain's head job. Source schema is the actual Rust migrations; this does not substitute for the missing verifier.
- **Operators:** actual `service_main.zig:150–176` binds message/Merkle/proof owners and Root controls. `ops/admin/api.zig:143–206` routes list/insert, queue inspection, retry/reprocess, gas CRUD, proofs, runtime denylist summary/refresh, nonce overwrite and opt-in environment operations. `agents/relayer/public_server.zig` is separately enabled/rate-bounded; validator routes are in `agents/validator/http.zig:100–115`. These are live bindings, not only DTOs/test mocks.
- **Metrics:** service Registry/schema and telemetry configuration are active, role adapters/common health/critical trackers are passed to owners. Source-independent role failures remain reason-specific. No new missing producer was established in the bounded readback; this does not certify every individual metric value under every chain fault.

## Stale documentation versus implementation

`docs/zig-agent-rewrite/parity-review.md` still describes WS producer wiring and some integration work as in progress. `ownership-review.md` still lists the two allocation defects as requiring fixes. Later paragraphs of `status.md` preserve earlier claims that generic validators, regex or origin wiring were unfinished. Those statements are stale snapshots, not evidence of additional missing implementation. Final docs should be reconciled after the new scraper guard closes; this audit did not edit them.

## Unknowns and acceptance boundaries

This is a bounded Source-contract/readability audit, not a line-by-line proof of every protocol/library function. It establishes one concrete omitted implemented behavior; it cannot prove absence of all remaining defects. No unexecuted test, generated library rebuild or daemon result is claimed.

Known outstanding acceptance remains separate: final common frozen source/default/native/PG/actual-role checks after fixes; exact newly built native SDKs; final Linux core/SDK images and operational configuration; all final immutable relayer 3-ISM/batch/crash/WS/public and validator/scraper processes; all matched build/runtime pairs and inventory; normal hooks/commit, review/provenance, push and draft PR. Earlier diagnostic failures and source identities must remain intact. The newly confirmed guard requires relevant correctness reruns before those gates can close.
