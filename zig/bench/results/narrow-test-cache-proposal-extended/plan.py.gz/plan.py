from pathlib import Path
import os,stat,hashlib,json,mmap,struct,datetime,subprocess,gzip,re,collections
base=Path('/tmp/ziggy-narrow-test-cache-plan.json');old=json.loads(base.read_text());needle=b'/Users/pbio/work/ziggy/zig/src';start=datetime.datetime.now(datetime.timezone.utc).isoformat();cutoff=datetime.datetime(2026,11,5,13,7,tzinfo=datetime.timezone.utc).timestamp();root=Path('/Users/pbio/.cache/zig');output=Path('zig/bench/results/narrow-test-cache-proposal-extended');assert not output.exists();output.mkdir(parents=True)
selected_dirs={str(Path(i['path']).parent):i for i in old['selected']};ids={Path(p).name for p in selected_dirs};all_h=list((root/'h').glob('*.txt'))
def sha(data):
 h=hashlib.sha256(data).hexdigest();return [h[:32],h[32:]]
def statdata(p,s):return {'path':str(p),'logical_bytes':s.st_size,'allocated_bytes':s.st_blocks*512,'dev':s.st_dev,'ino':s.st_ino,'nlink':s.st_nlink,'mode':oct(stat.S_IMODE(s.st_mode)),'mtime_ns':s.st_mtime_ns,'birth_utc':datetime.datetime.fromtimestamp(s.st_birthtime,datetime.timezone.utc).isoformat()}
def opened():
 r=subprocess.run(['lsof','-nP','-Fpn'],capture_output=True,text=True,timeout=45);d={};pid=None
 for line in r.stdout.splitlines():
  if line.startswith('p'):pid=line[1:]
  elif line.startswith('n') and line[1:].startswith(str(root)+'/'):d.setdefault(line[1:],[]).append(pid)
 return d,r.returncode,bool(r.stderr.strip())
before,rc1,warn1=opened();hfiles=[];hexcluded=[];herrors=[];direct=0
for p in all_h:
 try:
  s=p.lstat()
  if p.is_symlink() or not stat.S_ISREG(s.st_mode) or s.st_birthtime<cutoff:hexcluded.append({'path':str(p),'reason':'type_or_pre_task_birth'});continue
  data=p.read_bytes()
  if needle not in data:hexcluded.append({'path':str(p),'reason':'no_exact_checkout_src_binding'});continue
  end=p.lstat()
  if (s.st_ino,s.st_size,s.st_mtime_ns)!=(end.st_ino,end.st_size,end.st_mtime_ns):herrors.append({'path':str(p),'reason':'unstable'});continue
  name='manifest-backups/'+p.name+'.gz';target=output/name;target.parent.mkdir(parents=True,exist_ok=True);packed=gzip.compress(data,mtime=0);target.write_bytes(packed);assert gzip.decompress(packed)==data
  tokens=set(t.decode() for t in re.findall(rb'\b[a-fA-F0-9]{32}\b',data));links=sorted(ids&tokens);stem_matches=p.stem in ids;direct+=bool(links or stem_matches)
  hfiles.append({**statdata(p,s),'sha256_chunks':sha(data),'exact_src_binding':True,'backup':str(target),'open_pids_before':before.get(str(p),[]),'explicit_selected_output_id_tokens':links,'stem_equals_selected_output_id':stem_matches,'newer_than_acceptance_preservation_cutoff':s.st_birthtime>=datetime.datetime(2026,11,6,9,tzinfo=datetime.timezone.utc).timestamp()})
 except OSError as e:herrors.append({'path':str(p),'error':type(e).__name__})
dirs=[];direrrors=[];totals=collections.Counter()
for dirname,original in selected_dirs.items():
 p=Path(dirname)
 try:
  ds=p.lstat();names=sorted(c.name for c in p.iterdir());reasons=[]
  if p.is_symlink() or not stat.S_ISDIR(ds.st_mode):reasons.append('parent_not_non_symlink_directory')
  if names!=['test','test_zcu.o']:reasons.append('unexpected_children')
  children=[]
  for name in names:
   child=p/name;s=child.lstat()
   if not stat.S_ISREG(s.st_mode) or child.is_symlink():reasons.append('non_regular_child');continue
   with child.open('rb') as f:
    header=f.read(32);magic=header[:4];ft=None
    if magic in [bytes.fromhex(v) for v in ['feedface','feedfacf','cefaedfe','cffaedfe']]:ft=struct.unpack_from(('>' if magic in [bytes.fromhex('feedface'),bytes.fromhex('feedfacf')] else '<')+'I',header,12)[0]
    with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:binding=m.find(needle)>=0
   expected=2 if name=='test' else 1
   if ft!=expected:reasons.append('unexpected_macho_filetype')
   if s.st_nlink!=1:reasons.append('hardlink_child')
   if s.st_birthtime<cutoff:reasons.append('pre_task_child')
   digest=hashlib.sha256()
   with child.open('rb') as f:
    while chunk:=f.read(1024*1024):digest.update(chunk)
   h=digest.hexdigest();end=child.lstat();chunks=[h[:32],h[32:]]
   if (s.st_size,s.st_mtime_ns,s.st_ino)!=(end.st_size,end.st_mtime_ns,end.st_ino):reasons.append('unstable_child')
   if name=='test' and chunks!=original['sha256_chunks']:reasons.append('test_digest_changed')
   if before.get(str(child)):reasons.append('open_child_before')
   children.append({**statdata(child,s),'sha256_chunks':chunks,'macho_filetype':ft,'purpose':'test executable' if name=='test' else 'test compiler object','exact_src_binding':binding,'open_pids_before':before.get(str(child),[])})
   totals[name+'_allocated_bytes']+=s.st_blocks*512;totals[name+'_logical_bytes']+=s.st_size
  after_names=sorted(c.name for c in p.iterdir())
  if names!=after_names:reasons.append('directory_children_changed')
  dirs.append({'path':str(p),'dev':ds.st_dev,'ino':ds.st_ino,'names':names,'children':children,'concerns':reasons})
 except OSError as e:direrrors.append({'path':str(p),'error':type(e).__name__})
after,rc2,warn2=opened()
for item in hfiles:item['open_pids_after']=after.get(item['path'],[])
for item in dirs:
 for c in item['children']:
  c['open_pids_after']=after.get(c['path'],[])
  if c['open_pids_after']:item['concerns'].append('open_child_after')
canary=Path('/tmp/ziggy-cache-output-regeneration-20261106-sdk15/result.json');canary_result=json.loads(canary.read_text())
result={'status':'READONLY_EXTENDED_SCOPE_PROPOSAL_NOT_AUTHORIZED_NOT_EXECUTED','started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'prior_plan':str(base),'prior_plan_sha256_chunks':sha(base.read_bytes()),'selected_test_parent_count':len(dirs),'selected_test_parent_concerns':sum(bool(d['concerns']) for d in dirs),'parent_directories':dirs,'test_and_object_totals':dict(totals),'whole_output_allocated_bytes':sum(v for k,v in totals.items() if k.endswith('_allocated_bytes')),'source_bound_manifests':hfiles,'source_bound_manifest_count':len(hfiles),'source_bound_manifest_allocated_bytes':sum(x['allocated_bytes'] for x in hfiles),'source_bound_manifest_logical_bytes':sum(x['logical_bytes'] for x in hfiles),'all_global_h_txt_count':len(all_h),'excluded_manifests':hexcluded,'manifest_validation_errors':herrors,'directory_validation_errors':direrrors,'manifests_with_direct_selected_output_id_link':direct,'lsof_exitcodes':[rc1,rc2],'lsof_warned':[warn1,warn2],'canary':{'path':str(canary),'sha256_chunks':sha(canary.read_bytes()),'result_rows':canary_result['rows'],'qualification':'Isolated local/o and local/h source-bound manifest invalidation demonstrates regeneration semantics. No global cache mutation or compilation by reviewer.'},'scope_limits':['No unknown recursive entries: each selected parent must contain exactly test MH_EXECUTE and test_zcu.o MH_OBJECT, both regular post-task files with stable digests.','All manifests enumerated by exact task src binding/post-task birth, never timestamp alone; unbound global h files remain excluded. Backups preserve exact bytes.','Manifest source association does not by itself establish one-to-one causality to a selected output ID; direct token links reported separately.','Fresh/current acceptance outputs and pinned role/runtime files are not selected. Bound manifest list is an inventory, not blanket permission to invalidate current task acceptance caches.','Root/baseline independent preservation review and all compiler/test joins plus immediate validation are required before any later authorized execution.','Physical host df remains decisive; upper bounds do not waive the40GiB floor.'],'global_mutation':False,'compilation':False}
Path('/tmp/ziggy-narrow-test-cache-extended-plan.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['selected_test_parent_count','selected_test_parent_concerns','whole_output_allocated_bytes','source_bound_manifest_count','source_bound_manifest_allocated_bytes','manifests_with_direct_selected_output_id_link','lsof_exitcodes']},indent=2));print('errors',len(herrors),len(direrrors),'manifest_new_acceptance',sum(x['newer_than_acceptance_preservation_cutoff'] for x in hfiles))
