# Extended old test compile-output preservation proposal

Read-only proposal. No deletion, global policy change, source/runtime edit, compilation or benchmark was performed. Root/baseline independent preservation review and explicit subsequent execution authorization remain required.

Inventory 2026-11-06T10:29:16.269531+00:00 through 2026-11-06T10:30:14.392164+00:00: the original oldest1264 selected test executables have exactly1264 parent directories containing only `test` and `test_zcu.o`. Each test is verified Mach-O MH_EXECUTE; each object is MH_OBJECT. All2528 children are regular, non-symlink, post-task, single-link files, independently contain the exact checkout src path, have stable recorded SHA256, and were absent from both lsof snapshots. Parent-child sets did not change; zero unknown entries, subdirectories, runtime/library/data children or validation errors.

| Exact old output set | Allocated bytes | GiB |
| --- | ---: | ---: |
| test executables | 6,716,342,272 | 6.255 |
| paired compiler objects | 10,973,016,064 | 10.219 |
| whole selected directories | 17,689,358,336 | 16.474 |

The binary-only6.255GiB proposal cannot reach40GiB from the reported31GiB free. Whole-directory16.474GiB is an allocated-size upper bound, not an observed reclaim or floor guarantee. APFS sharing and other writes still require host df readback after any separately authorized operation.

Global manifest inventory:1098 `h/*.txt` examined;557 stable regular post-task files contain exact `/Users/pbio/work/ziggy/zig/src`. The541 unbound manifests are excluded. Bound manifests total55,033,856 allocated bytes (about0.051GiB). Exact original bytes are losslessly backed up individually under manifest-backups and bound to original path/stat metadata/SHA chunks. No manifest content, other than pathname metadata, is printed. A supplemental check found only the ziggy checkout under `/Users/pbio/work/` in all557, with no other project root.

Two bound manifests were open in lsof and cannot be altered while their jobs run.14 bound manifests were born since09:00 Nov6, and 19 were modified since that boundary; these are tagged for current/future acceptance preservation review. The full557 list is an inventory and backup set, not blanket invalidation permission. All task compilers/test children must join, then exact metadata/hash/handle checks must be repeated. A changed manifest must not be removed using stale inventory.

Regeneration evidence is now resolved in Root's isolated task-only canary: initial command passes; cached executable-only removal returns FileNotFound; whole own output-directory removal also returns FileNotFound; removing one exact source-bound same-cache `local/h/*.txt` then rerunning the identical command regenerates and passes. Original bytes were backed up. This reviewer performed no canary mutation/build. Exact result and logs are archived with this proposal.

The canary establishes the need for corresponding manifest invalidation. No selected output-directory digest appears as a direct token/stem link in the557 global manifests, so this audit cannot claim a one-to-one companion mapping from their plaintext alone. Source binding provides a narrow task-only invalidation scope; Root's independent mapping/regeneration review must decide the exact permitted set. Do not replace that decision with unrelated/global h deletion. A task-source-bound manifest may cover a newer task compilation or role cache even when no role binary is selected; invalidating it forces a future compilation cache miss, not deletion of a pinned runtime.

Realistic cost: whole-directory removal drops both the historical test executable and its code-generation object; after correct manifest invalidation, reruns need object generation/linking, potentially compiling imported modules. Removing an exact manifest also loses its dependency-digest shortcut. Losing future cache reuse is ordinary cache cost, not a reason to require impossible proof against future use. Missing companions would instead preserve the actual FileNotFound failure, which remains an execution-procedure concern.

Preserved: every unlisted global output directory/file, all unbound h manifests, all b/z/tmp cache areas, source/toolchain/download/SDK/parameter/fixture data, role binaries/pins and runtime dependency closure, raw test/benchmark evidence, and future outputs. The previous proposal's six evidence-referenced cached executable paths and21 newer outputs remain excluded (25 unique exclusions). Selected parents are born no later than07:55 Nov6; subsequent acceptance outputs do not enter this fixed whitelist. No existing ownership helper or cache policy was weakened.

Machine plan `/tmp/ziggy-narrow-test-cache-extended-plan.json` contains every child/hash and exact manifest backup metadata. SHA256 chunks concatenate in order. The existing earlier blocked binary-only proposal is preserved as historical; this extended proposal does not execute it.
