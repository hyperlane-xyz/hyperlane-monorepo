# Cosmos RPC physical / aggregate timeout correction — released

Owned writes: `zig/src/evm/pool.zig`, `zig/src/net/read_replay.zig`, NEW `zig/src/cosmos_rpc_timeout_testing.zig` and its focused root `cosmos_rpc_timeout_tests.zig`. Parent exclusively integrated `agents/chain_source.zig`; protocol owner integrated HTTP/Factory/receipt clocks. No changes to those files by this worker.

## API / implementation

- `Pool.FallbackConfig.attempt_timeout_ms: ?u32 = null`: optional physical per-peer cap, valid1..300000ms; submitPeer uses min(cap, remaining aggregate session), separately from existing hedge limits. It does not enable hedging or alter method/remote-error/ID/result classification. Null preserves EVM/default request budgeting.
- `ReadReplay.Config.use_owner_timeout: bool = false`: opt-in requires fallback with a nonnull physical cap or returns `MissingReadReplayPhysicalTimeout`. The session receives the retained replay owner's actual remaining budget; entries are owner_limited so an aggregate/clamped timeout retains control status, including boundary rounding. Callback passes and commitReadSection never refresh that deadline. No new production heap allocation or worker/thread.
- Parent integration reviewed: Cosmos/CosmosNative-only20s cap; owner-timeout Replay; borrowed protocol/physical-cap validation; direct exchange context Resources uses min(bounded120s per-call session, explicit rpc_deadline_ns, HTTP RpcReadOwner) and cancellation/halt/expiry checks before/after, freeing returned bytes on post-check failure. No blocker found in the configured production paths.

## Verification

| Root / scope | Passed | Skipped | Detail |
| --- | ---: | ---: | --- |
| Final actual Cosmos Resources root | 19 | 0 | 13 owned substantive cases +2 parent budget cases +4 import/root smoke cases |
| Existing native delegated Pool root | 86 | 0 | Ordered/default/EVM remote errors, exact bytes, cancellation and allocator failure sweeps |
| Existing producer/header/replay focused root | 37 | 0 | RPC producers, typed headers, completed timeout clamp/cancel/injected-clock rules, identity/allocation checks |

Final19/19 uses actual `Resources.open` → production Tendermint RPC clients for both Cosmos direct and CosmosNative cooperative modes. Each first peer accepts the real request then physically stalls for the configured full20s; healthy B responds afterward under the120s owner. The two cases assert elapsed>=19.5s (the physical cap remains exactly20000ms), no hedge, one hit per peer, exact same underlying on-wire request/large ID, and preserved result integer9007199254740993. The direct case binds actual absolute rpc_deadline_ns and HTTP owner; the cooperative case proves the constructor's cap and owner-timeout flag rather than manually wiring them.

Actual Resources negatives cover direct Clock clamp/cooperative retained-owner expiry with zero B requests, expired direct Clock/precancel with zero total admissions, and capless/different-cap borrowed Pool rejection. Positive read fork borrows the existing capped Pool while keeping its own absolute replay journal; the fixture retains its borrowed environment through child/parent teardown. Lower-level cases additionally cover accepted-A cancellation/drain, section deadline persistence and byte quota return, existing method-error fallback/exact IDs, owner cap validation, and unchanged legacy aggregate timeout without opt-in.

The final run records **eight selected source hashes identical before/after**, including owned production/tests and Parent/protocol integration files. This is focused functional evidence, not an entire-tree or performance acceptance claim. Existing86/37 regressions ran with unchanged owned Pool/Replay production hashes; they are separate roots and must not be summed as unique project-wide tests. All production heap allocation paths remain the existing ones; the existing Pool and replay allocator sweeps pass. Native sessions and retained replay bytes retire after success/control failures.

## Evidence / limitations

- `/tmp/ziggy-cosmos-rpc-timeout-resources-{command.json,result.json,tests.log}`: final19/19 actual Resources proof, selected before/after hashes.
- `/tmp/ziggy-cosmos-rpc-timeout-regression-results.json` plus `regression-{pool,producers-and-replay}.log`: exact argv/env and86/37 results.
- `/tmp/ziggy-cosmos-rpc-timeout-release-source-hashes.json`: four released owned sources.
- Historical initial8 and lower-level10 proofs, earlier Resources18 proofs, and their logs remain separate under `/tmp/ziggy-cosmos-rpc-timeout-*`; final19 supersedes them. An initial test-literal syntax error was corrected before the initial8 proof. The later fixture environment lifetime correction preceded final Resources acceptance; the final positive read-fork case exercises that lifetime.

No SDK, Rust/C, agent role, Docker image, benchmark, production endpoint or credential operation. Only Zig focused test compilation and disposable local native HTTP fixtures. Both final20s cases are liveness/correctness tests, not CPU/throughput measurements. Parent owns standard aggregate wiring, durable evidence archival and final global acceptance against final emitted artifacts. Import `cosmos_rpc_timeout_testing.zig` into the native RPC aggregate to retain the cases there; this standalone root is `cosmos_rpc_timeout_tests.zig`.
