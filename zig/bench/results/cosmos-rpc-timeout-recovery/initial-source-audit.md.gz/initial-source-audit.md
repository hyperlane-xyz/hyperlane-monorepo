# Direct VM timeout / Source fallback audit

Read-only source inspection. No edits, builds, daemons, SDK loads, benchmarks, credentials or live RPC requests. The parent global functional run remains independent. Traces below are deterministic control-flow triggers, **not executed reproductions**.

## Findings

**P2: direct Tron and Aleo read fallback misclassifies a physical timeout as owner control.** Rust supports trying the healthy second endpoint after the first provider times out. The native direct HTTP path returns before that second endpoint, even when the real enclosing owner deadline remains live. Cooperative HTTP replay already distinguishes the two timeout scopes.

**P2: Cosmos Tendermint RPC has a separate budget conflation.** Its nonhedged Pool session gives the first physical request the entire configured20s session budget. On a full response stall the Pool expires before a second peer can start, although the enclosing cooperative read attempt has a120s budget. Mapping the completed Pool timeout to `UpstreamReadTimeout` does not itself give the second endpoint time or rotate it. This is distinct from `net/json_rpc.isControl`.

| Family / HTTP path | Rust Source | Current native behavior |
| --- | --- | --- |
| Tron wallet / wallet-solidity read | Configured channels use reqwest30s plus generic FallbackProvider30s per provider; failure advances to next channel | Direct curl20s failure reaches `isControl(RequestDeadlineExceeded)` and aborts before B |
| Tron Ethereum-compatible JSON-RPC read | Configured URLs are wrapped by EthereumFallbackProvider + generic fallback | Same direct HTTP classification aborts before B; this path is its own Tron Pool, not Resources' EVM Pool |
| Aleo ordinary GET / optional GET transport failure | Ordinary `AllErrors` fallback, generic per-provider30s; base reqwest request120s does not remove the30s outer provider bound | Direct curl20s timeout is control, so GET loop stops before B |
| Cosmos / CosmosNative Tendermint JSON-RPC | Configured clients inside generic fallback,30s per provider | Nonhedged native Pool shares one20s deadline across endpoints; full20s A stall consumes B's admission budget |
| Cosmos gRPC | Configured gRPC endpoints30s plus generic fallback | Direct mode treats physical Deadline as failedAttempt and advances. Cooperative mode receives `UpstreamReadTimeout` from HTTP replay. No same control-classification defect found |
| Radix Core / Gateway reads | Configured lists each inside generic fallback;30s per-provider outer timeout, no explicit reqwest timeout in this constructor | Ordered REST loop already continues after physical `RequestDeadlineExceeded`; no same bypass found |

The native20s and Rust30s are different configured physical/provider bounds. This finding is about fallback after a bounded failure, not a claim that both implementations already have identical timeout values.

## Common Rust Source contract

`rust/main/hyperlane-core/src/rpc_clients/fallback.rs:35` sets the default call timeout30s; builder default at498 retains it. `call_provider`179–204 wraps the provider future and its stall check in `tokio::time::timeout`, returns a normal ChainCommunicationError on expiry, and records provider failure. `call`355–359 uses the all-errors retry predicate. `call_with_retry_predicate`380–402 iterates the remaining configured providers after an error. Timeout is not converted into cancellation of the caller's whole future.

Setup / actual entry points:

- Tron: `chains/hyperlane-tron/src/provider/http_client.rs:64` configures reqwest REQUEST_TIMEOUT (30s, const near file top); channels166–171 enter the fallback. `get_now_block`175–183 calls it. `chains/hyperlane-tron/src/utils.rs:42–54` wraps every configured Ethereum-compatible RPC URL in fallback and EthereumFallbackProvider.
- Aleo: `chains/hyperlane-aleo/src/provider/fallback.rs:84–90` selects `AllErrors`;114–122 builds generic fallback without overriding its30s default; ordinary GET207–224 calls it. `provider/base.rs:21–22,59–61` has30s connect/120s HTTP request bounds. Delegated proving selects a separate retry policy and is excluded from this read-fallback finding.
- Cosmos: `chains/hyperlane-cosmos/src/providers/rpc.rs:190–206` collects every configured RPC client into fallback; RPC constructor139–156 does not add a separate explicit timeout. `providers/grpc.rs:28–30,80–88` configures30s channel/connect bounds and fallback.
- Radix: `chains/hyperlane-radix/src/provider/radix.rs:96–144` constructs separate configured gateway/core client lists and fallback wrappers. `provider/fallback.rs:29–35,115–135` routes actual status/preview reads through them.

## Native trigger and precise path

Configure two endpoints A then B. A accepts the connection (so the5s connect bound is not the terminating condition) and stalls the response for the full configured20s. B can return a valid response immediately. No cancellation flag is set. If a real enclosing owner starts with120s, about100s remains after A; equivalently the defect is unchanged if its remaining budget is still120s when A completes.

Resources: `zig/src/agents/chain_source.zig:25,35–36` defaults to request_timeout20s, cooperative=false, replay-attempt120s. It creates a native Curl client117–130 and binds HTTP timeout20s/connect5s130–131. The main relayer destination path uses these direct defaults: `agents/relayer_task.zig:220–222` opens destination Resources; `sourceOptions`1795–1796 supplies the physical timeout; `destinationOptions`1804–1810 does not enable cooperative reads.

**Important owner qualification:** `read_attempt_timeout_ms=120000` alone is **not** an active absolute Clock in direct mode. HTTPReplay is only allocated for cooperative mode (`chain_source.zig:119–126`). Do not claim a120s direct owner solely from that config field. The live-owner trigger above assumes a real enclosing owner; the rejection is independent of its remaining positive budget because the client never checks that budget when classifying the physical error.

1. Tron Resources wires its three complete endpoint pools to the direct shared HTTP transport (`chain_source.zig:247`; `tron/provider.zig:79`). Actual finalized header path: `agents/scraper/tron.zig:35–39` → `tron/provider.zig:82–84` → solidity `walletValidated` → `tron/rpc.zig:59–61`. A's error returns at61, not `continue`; B is uncalled. The same check is at89 for Ethereum-compatible JSON-RPC (`energyPrice`, balance, receipt use that Pool).
2. Aleo Resources wires the HTTP transport at `chain_source.zig:259`; concrete Factory retains all configured URLs in `agents/scraper/aleo.zig:282–289`. `aleo/provider.zig:24–27` latest height → `aleo/rest.zig:43–59` GET endpoint loop. A's error returns at57; B is uncalled.
3. Both errors originate in real `curl.Transfer.finish`: `net/curl.zig:458–460` checks cancellation/OOM then maps CURLE_OPERATION_TIMEDOUT28 to `RequestDeadlineExceeded`. `cloud/http.zig:106–109` preserves it. `net/json_rpc.zig:88–92` categorizes it as control. Neither Tron nor Aleo can determine from this error alone whether it was a physical or owner-clamped timeout.
4. Cooperative path differs: `net/http_replay.zig:94–96` checks cancellation/absolute remaining time; completed physical timeout106–115 becomes `UpstreamReadTimeout` only while the replay budget is live. Requests are clamped at141–142. Ordinary origin tasks explicitly enable cooperative reads (`agents/origin_tasks.zig:105,168`), so the direct finding must not be described as universal failure of every production indexing read.

## Cosmos RPC budget trigger (separate mechanism)

`chain_source.zig:136,139–147` selects Tendermint height protocol and fallback with **hedge=null** for Cosmos/CosmosNative. Resources constructs one Pool containing every RPC URL; `r_options.timeout_ms` is20s (`:133`). `:174–181` uses ReadReplay only when cooperative; direct mode also passes the same request bound to the Pool.

`evm/pool.zig:637` sets session deadline to start+timeout. `submitPeer`1551–1560 assigns A all remaining session time; only an explicitly configured hedge supplies a shorter attempt bound. The Pool loop775 expires the session **before** `progress`776, and `submitPeer`1527–1529 also refuses an already-expired session. Thus an A response stall lasting that whole20s prevents B in that session. This holds even when `net/read_replay.zig:142–145` later remaps the completed session timeout under its still-live120s owner. Early connection/HTTP/method failures can advance within20s; they do not disprove the full-response-stall trigger. No claim about indefinite behavior across separate caller retry cycles is needed for this finding.

## Preserved controls and minimal correction

Do not remove `RequestDeadlineExceeded` globally from `isControl` or globally widen method-error retries. Preserve true absolute-owner expiry, `SourceReadDeadline`, `ScraperReceiptDeadline`, cancellation, pending I/O, OOM and capacity controls. A well-formed JSON-RPC remote error remains method/domain evidence: `net/json_rpc.zig:61–70` preserves its code/data rather than treating it as a transport timeout. Existing Tron/Radix/Aleo status/error handling is a separate contract; this correction should not change it. Radix `/transaction/submit` and Aleo POST remain single-endpoint uncertain-send paths (`radix/provider.zig:67`; `aleo/rest.zig:38–46`). Do not broaden broadcast/prover replay.

For direct Tron/Aleo, use a producer-bound HTTP adapter with explicit physical-timeout provenance and actual owner deadline/cancellation checks. Normalize a **completed physical**20s request failure to the existing `UpstreamReadTimeout` only when the request was not owner-clamped, the actual owner remains live, and cancellation is false; retain the20s physical bound. Keep true owner expiry as control. No need to change each method's fallback/error policy.

Cosmos RPC additionally needs distinct per-peer physical bounds and aggregate-owner/session budget (or explicit retained endpoint rotation under the same live owner), so a20s A timeout can leave B runnable. ReadReplay normalization alone cannot fix that admission issue. Keep the whole-operation deadline bounded; do not obtain fallback by granting each attempt a fresh whole-owner timeout. Parent/protocol owner must assign and test any correction; this audit made none.

Required focused proof before closure: real native two-endpoint fixtures for direct Tron wallet and JSON-RPC, Aleo GET, and Cosmos Tendermint Pool, with A accepted/stalled, B valid, live owner→B success; owner-expired and cancellation→zero B requests; owner-clamped near-boundary timeout→control; exact request identity retained; ordinary method error semantics unchanged. Existing Radix/gRPC paths should retain their working deadline/fallback behavior. No such fixture was run in this read-only audit.
