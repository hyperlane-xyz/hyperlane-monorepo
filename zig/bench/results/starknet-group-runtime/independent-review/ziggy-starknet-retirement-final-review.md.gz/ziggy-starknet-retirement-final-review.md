# Starknet atomic retirement final read-only audit

Status: pre-release Source review; no additional code blocker identified. Runtime owner is still fixing new integration tests. Current proof integration log is45 passed/1 failed, with the included-GC healthy-later-group case unresolved. This is not final acceptance. No Source/test edits, role/SDK build, benchmark or production request by reviewer.

## Durable state boundary

`Operation.commitGroup` snapshots every actor before locking; each creation expression retains errdefer cleanup for cloned intent/signed/encoded row, and all successful snapshots are deinitialized on later failure. Unique store pointers are sorted, aliases of the same namespace are rejected, actual actor rows/status and journal CAS plus canonical message/inherited authority/member links are checked under those locks. No I/O callback runs under the locks. One synchronous WriteBatch writes the terminal group record and every undelivered retry row/status/count while preserving already delivered members. In-memory application occurs only after successful commit and allocates nothing. Before-commit failure leaves old signed owners; post-commit/unknown errors require reload, with no live partial application.

`Journal.retire` persists full32-byte consumed account/saved/observed nonce, same finalized height/hash and absent-member bitmap in phase.retired. Scalar Operation independently validates proof kind/target/identity/digest/generation/account/Felt ranges, observed>saved and absence_checked. Each undelivered group member needs its own sameH proof; delivered members are preserved and require null memberproof. Final failed receipt uses the separate atomic failed transition with exact shared identity and finalized failure.

Terminal retirement deliberately has two recoverable stages: terminal journal+member retry rows/current-pointer release are one WAL; member links/fullnonce reservation remain until terminal GC. Links suppress unsigned native preparation while that cleanup is pending. GC validates the terminal actor states, CAS/link/reservation ownership, atomically archives the complete signed journal and removes its links/reservation without clearing another current owner. No member can reprepare the old nonce while its terminal group is still linked.

## Previously reported concrete gaps

The earlier all-independent-delivery orphan shortcut is removed. advanceSignedGroup obtains positive configured-finality nonce consumption when the original receipt is absent, using sameH per-member absence for undelivered members. All-delivered mailbox state alone cannot clear its reservation. A valid finalized canonical original receipt is the other permitted completion path. Exact old bytes can be replayed when the nonce remains unspent; no subset re-sign or600-second reset occurs.

The per-Actor partial-failure variant is fixed in NativeDriver: group_owned returns before finalizedFailure or scalar retirementProof mutation. It still permits read-only delivery/finality reconciliation and once-only fee recording; atomic Root failed/retired owns group resets. Ordinary group receipt failures return completed work so per-member delivery drains, and included-GC loops advance after ordinary errors.

Unknown-fee nonce retirement does not fabricate zero spend: the proof has no expenditure and the retired transition writes no expenditure marker/row. Canonical final failed receipt accounting is idempotently recorded before the atomic failed transition; recoverable journal preserves full identity/intent/evidence history.

## Remaining validation gate

Owner must release its final Source and accepted integration command/log, including all-independent-delivered orphan reservation, full-Felt consumption, finalfailed per-Actor interleaving, before/after-WAL crash+freshFactory/Rocks reopen, and later healthy included-GC progress. Current45/46 log cannot establish full acceptance. Recompare the five Source hashes after owner release and inspect the formerly failing GC test. Parent owns permanent db_tests/native sender/control registrations and postSDK Docker CI execution; these must be checked after owner wiring release, not treated as missing released features while still in progress.

Current reviewed production hashes (unchanged throughout this pass):
- zig/src/agents/relayer_task.zig: 0d3420f0f10c3fae0588b5e36505d4969318f2df3c2413b37c45c92898eaa3a9
- zig/src/agents/destination/operation.zig: 6b98057b8a54cb824eb2ab0f18703c804f63354f5c166c13bc5e687eee888b6a
- zig/src/agents/relayer/native_group.zig: 2268edd3262eda6bd8729546fd871c2a8c957149d68afa450bb2b0ec811a2402
- zig/src/agents/relayer/native_driver.zig: 1539cc2df5784b6b0ab83068c4a429ee2fbea0535d5dfceea6dc4bdf780e0e7f
- zig/src/agents/destination/types.zig: 09f3c3a311111a9e30511638097683972a1ff30b17e185903450f6e7f6887fe1

## In-progress follow-up readback

Parent postSDK Docker stage now exports actual LinuxSDK/curl/libcrypto for both the filtered Starknet component root and native-db-test with reloaded seven archives plus GNU unwind. Current db_tests70–73 registers actual group, guard, control and native sender roots. This is verified wiring, not a claimed Docker image run.

The new canonical-receipt fence had a concrete refresh wedge: existing final canonicalA plus later successful final canonicalB refused cleanup but did not persist B. Reported immediately; latest Root now persists changed canonical candidate before requiring a fresh match. New regression/final owner release remains pending. The original unchanged-five-file snapshot is now historical; compare final production hashes before approval.

## Released94/94 snapshot and remaining shared-deadline scheduling issue

Owner released combined94/94 zeroSkip and all16 source hashes unchanged across the run. Reviewer independently compared the exact frozen16 hashes to current files and verified the complete94/94 log. CanonicalB refresh regression, atomic full-Felt WAL cuts, all-delivered orphan, partial per-Actor failed receipt, and lower5/higher6 exact-byte replay all pass. Root's canonical_changed predicate is corrected.

Parent then requested a specific remaining deadline-fairness audit. Confirmed in released Root45dea7...: one native_group_deadline_ns covers the whole tick; GC always precedes direct current-owner advancement. A hash-specific old receipt RPC that consumes the aggregate deadline propagates RequestDeadlineExceeded/ScraperReceiptDeadline through hard control classification, or leaves the next frame/Factory.begin already expired. Cursor advancement rotates old entries, but current-owner progress still waits O(total old journal count) before a pass reaches the end without another old stall. A healthy current must have a first scheduling chance independent of that count.

Minimal correction proposed to parent/owner: retained Lane priority bit toggled before backend callbacks, alternate current-first and GC-first passes while preserving one unchanged tick deadline and normal20-second physical request deadlines. Each side gets first chance at least every two passes; still allow the other side in the same pass when budget remains. Add at least3 old receipt-specific exhausted-deadline journals plus healthy current; assert current sign/broadcast progresses within a fixed bounded number of passes independent of old count, old GC cursor/lower orphan still progress, and no re-sign/nonce/deadline weakening. No edits by reviewer. Final approval remains pending this narrow gate, despite verified94/94 prior snapshot.

## Final released95/95 Root approval

Owner corrected shared-deadline fairness with a retained priority bit toggled before callbacks. Current-first and GC-first alternate under one unchanged absolute tick deadline, with maximumtwo old journal attempts; an expired budget skips the other phase rather than granting a new timeout. The actual SDK/Rocks regression withthree hash-specific old deadline records lets healthy current sign/broadcast withinfour passes without extra quote/nonce reads or shorter physical timeouts; lower5→higher6 remains green.

Final owner log `/tmp/ziggy-starknet-group-final-priority-tests.log` passes95/95 zeroSkip, exit0. Reviewer independently matched all16 frozen Source hashes from `/tmp/ziggy-starknet-group-final-priority-source-before.json` to current files, verified the complete result/log, and read the priority implementation and new regressions. No unresolved Root/Operation retirement blocker remains in this snapshot. Root7a467268e4a32550a67de1f050b338b25e98ac6bb0adc8df0f22dd0934a860a7; Operation6b98057b8a54cb824eb2ab0f18703c804f63354f5c166c13bc5e687eee888b6a; nativeGroup2268edd3262eda6bd8729546fd871c2a8c957149d68afa450bb2b0ec811a2402. Reviewer did not repeat SDK/role/performance builds.

Separate pending transport audit: /tmp/ziggy-generic-physical-timeout-review.md. Root approval does not close direct generic-VM physical-timeout producer classification.
