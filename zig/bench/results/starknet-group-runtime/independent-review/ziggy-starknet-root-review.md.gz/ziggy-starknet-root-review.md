# Starknet Root coordinator independent review

Status: read-only review of unreleased, actively changing integration. No production calls, role builds, SDK rebuilds or performance timings. No Source/test edits by reviewer. Prior atomic helper independent acceptance is separate: `/tmp/ziggy-starknet-atomic-review.md` (15/15 focused tests).

## Findings and closure gates

### P1: restored native operations can skip the initial origin signer lookup — production fix landed, regression acceptance pending

Original Root Sender.check used a cached-only origin signer lookup for native Driver build/rebroadcast and returned allow when cache was empty. Group recovery also constructed temporary Active state rather than preserving Source lookup/backoff. A fresh process therefore allowed a restored Ready or signed operation to sign/rebroadcast without looking up an origin signer denied by configured address rules. The group frame can include members not loaded into Active, so ordinary advance could not repair this before group signing.

Variant audit: `native_driver.zig` step skips its initial gate for existing stage.ready, then build uses cached=true; signed reconciliation similarly uses cached=true before exact rebroadcast. All native destinations shared the Root Sender implementation. Fresh EVM/native preparation performs the initial lookup. EVM independently durable Lander payload recovery is a different Source boundary and is not included in this finding.

Source: `rust/main/agents/relayer/src/msg/pending_message.rs:500–579` performs initial lookup, 30/60/120/240-second backoff and bounded give-up; cached-only checks are secondary during the give-up pause. Recovered pending messages enter preparation via `pending_message.rs:957+` / `db_loader.rs:1015+`.

Current fix readback: `relayer_task.zig:660–741` centralizes the initial lookup in originSenderGate, retaining per-message checked/backoff/deadline state; native Sender.check delegates to it. Group state is bounded to4096 entries, charged against Root retained memory, removed on Active completion/settled journal cleanup, and destroyed on Lane teardown. Cached signer denials still apply even during cooldown. Need actual cold-restart Ready, signed and non-Active group-member lookup/backoff/denial tests before final acceptance.

### P1/P2 availability: ordinary group receipt/broadcast errors abort all per-member progress — production fix landed, GC variant remains open

Original tickNativeGroups propagated ordinary factory.reconcile/broadcast errors through cycleInner before any Active.advance. A persistent malformed/noncanonical receipt or unavailable receipt RPC therefore prevented independent finalized mailbox delivery proofs and600-second completion for every actor. Scalar NativeDriver.reconcile already isolates ordinary receipt errors and can complete from deliveredFinalized; Source pending-message confirmation checks mailbox delivery independently.

Current fix readback: groupRpcFailure reports ordinary errors and returns completed work, preserving hard/control/persistence failures. This lets the ordinary Active drain run without treating malformed receipt as missing, rebroadcastable or finalized.

Remaining concrete variant: included-phase catch sites around `relayer_task.zig:910–933` return before the common cursor increment near1044. One persistently failing included journal pins native_group_gc_cursor forever and starves every lexicographically later included journal. Preserve the reservation and exact-byte ownership, but rotate the bounded included-GC cursor on an ordinary failure. Regression requested: at least two included journals; first continuously errors, later journal still reconciles/clears and normal per-member drain continues. Runtime owner notified immediately.

### P1: mixed independent delivery after group reorg blocks remaining members — open owner assessment

Concrete supported combination: original A+B group inclusion is nonfinal and disappears in a reorg; another relayer independently finalizes only A. Ordinary NativeDriver eventually marks A delivered, while B stays undelivered under the original shared group. Included GC requires every actor to be non-delivered before exact-byte replay (`relayer_task.zig` included loop around918); Persistence.intent similarly rejects delivered members (`native_group.zig:169`). B's group_owned driver suppresses independent broadcast. The journal cannot settle because B still has the original signed intent, and the reserved nonce prevents replacing the original transaction at that nonce. Current all-members-undelivered reorg test does not exercise this case.

Owner notified with exact trigger. Need a whole-group retained-byte/nonce reconciliation policy and actual mixed-delivery reorg test. Never silently drop nonce reservation, subset re-sign, reset600-second confirmation, or weaken current actor authority guards. Whether replay itself executes or reverts for already-delivered A is contract-dependent; refusing any replay still leaves B without a progress path. A finalized failed shared transaction can safely establish nonce consumption before B's later ordinary generation.

### Submitted metric variant — fix landed, acceptance pending

Original groupSubmitted only counted loaded Active members. If current-process inclusion involved members outside max_active, they later restored Confirm.SubmittedBySelf and suppressed the process counter entirely. Current implementation records every current-process member using a persisted random observation_epoch, deduplicates group IDs in bounded retained state, and suppresses historical restart counter replay. Need actual mixed loaded/unloaded membership and post-commit recovery tests. Optional telemetry failures remain best effort.

## Parent-known gates, not additional findings

The scalar Factory receipt allocation guard, all-zero singleton fallback cleanup and imported Rust Ready-without-native-intent handling were already found and fixed by parent/owner. Reorg/reserved-nonce/exact-byte600-second behavior remains an integration acceptance gate, not a claim that the first implementation was complete.

Current model inspected: prepared/signed journal owns current pointer; per-nonce reservation survives nonfinal inclusion. Included reorg recovery retains executable bytes and cannot re-sign or reset confirmation time. Settled cleanup atomically archives journal and removes exact matching reservation/member links under unique sorted origin-store locks. Candidate collection retains only bounded popped-state booleans across PIO, never Actor pointers; deferred ownership cleanup covers denied candidates and all-zero fallback selection. Fresh clock reads surround quote and durable barriers. No additional ownership/OOM bug found in these paths during this read-only pass.

## Verification limits

No whole Root SDK suite run by reviewer while owner Source is active. Owner first21/21 and expanded suites are owner evidence until final source freeze/readback. Focused helper15/15 is already independently verified in the separate atomic report. Root final acceptance still requires cold signer-cache variants, ordinary receipt-error delivery drain/GC fairness, current+reserved nonce reorg/collision lifecycle, fresh Factory/Rocks reopen, all-zero/scalar accounting, PIO submit-cap exclusion and N-member submitted counters.

## Working snapshot hashes (not a freeze)

- relayer_task.zig: d1cf78779ce2ae3442a8fb50e7a113f3eb8e2c249022a0113f4ebc67a3780af0
- relayer/native_driver.zig: 0aa1aa73039c7b02186a9d19a74ea9349120b23e0536b7747504acc314c2ca6e
- relayer/native_group.zig: 14434135472d6408d963a0e164b6a09b805178c77cd57e4f44f9578858628c29
- destination/factory.zig: 72453d3251507058b395d0e83888bcd0b49622ad753163062a4d442062e36724
- starknet_group_native_test.zig: 4ddb15689a8546a2e70b994f3eee849aaa296d0f12bf27c2ea54b40c299807c1

## Final owner-freeze readback (subsequently reopened for adjacent finding)

Read the current fixes and owner accepted logs: `/tmp/ziggy-starknet-group-expanded-tests.log`35/35 and `/tmp/ziggy-starknet-group-control-tests.log`26/26. No duplicate wholeSDK run by reviewer, per parent gate. Included GC uses a labelled recovery block so ordinary failures still advance the bounded cursor. The actual later-healthy-group regression passes. Common retained SenderState cold-cache lookup/backoff is covered by actual control tests. Submitted counters cover cold members outside Active and historical restart suppression. Mixed A-only delivery after reorg now replays only the retained bytes, permits delivered stage solely in the explicit included-rebroadcast callback with exact row/link/nonce/signed-byte guards, records finalized fees for all members, and lets only the undelivered member retire to a fresh generation. The actual mixed A-only canonical revert test passes. These original findings are closed by Source readback plus owner evidence.

### Remaining P1: all independently delivered members do not establish signed account-nonce retirement

Concrete adjacent case: included nonfinal A+B is orphaned; another account/relayer independently finalizes BOTH messages. Included settled predicate then clears journal/reservation solely because both actors are delivered. Phase.signed has an analogous all_delivered shortcut. Mailbox delivery proves message completion, not consumption/retirement of this account's retained signed nonce5. If getNonce(latest) remains5, a new journal can sign different executable bytes at5 while the old original remains executable on the network (and may canonically revert because delivery already occurred). This violates the retained signed nonce-identity invariant and can strand the newer transaction when the older one consumes5.

Sent runtime and parent immediately. Require an explicit original canonical final outcome/account nonce retirement proof before releasing its reservation; do not silently discard retained signed ownership based only on mailbox state or subset re-sign. Current owner may be actively changing this path, so the preceding frozen hashes are a working snapshot, not final acceptance.

Readback hashes:
- zig/src/agents/relayer_task.zig: 5307fed7800e011e5f4ac98e45a6f0da3f536791959d23e47cba601d1eafdda7
- zig/src/agents/relayer/native_group.zig: 29c04d5997b78c60e49556e6410599226c67446349755f782b74021af43deb3c
- zig/src/agents/relayer/native_driver.zig: 9fac87b29a755d573537dbc40666f93878fba2b17f3fd1fec48cf239480ed40a
- zig/src/starknet_group_native_test.zig: 7037ca9f98c1c8aa2f1ad9888d2a56d71841b51c53d028f55120c20a73f07161
- zig/src/starknet_group_control_native_test.zig: d1412006ade149b7a78eaa7aa50028c4fce4bb3f9a2ebc5c14e024cb398f92d1

## Positive nonce-proof correction integrated, final Root gate pending

The separate backend/Factory nonce/announcement primitive is released and independently accepted: focused16/16 zeroSkip, aggregate44/44, all10Source hashes and existingSDK digest independentlyverified. It validates scalar/batch/announcement signed body authority and full-width configured-finality nonce consumption with same-H canonical fences. See `/tmp/ziggy-starknet-nonce-proof-review.md` and canonical gzip artifacts in `zig/bench/results/starknet-nonce-proof/`. This closes the proof primitive gap; Root coordination acceptance is separate.

Current unreleased Root readback obtains a consumed-nonce proof before clearing all-independently-delivered reservation ownership and uses same-H per-member absence proofs for undelivered actors. Runtime owner added atomic GroupTransition.failed/retired and terminal journal phase to prevent partial actor-row retirement. The adjacent NativeDriver group_owned per-Actor finalizedFailure/retirement mutation was identified during readback and owner confirms it now defers to atomic coordinator. Await `/tmp/ziggy-starknet-group-proof-integration-tests.log` final release/hash signal before calling the Root all-delivered-orphan/nonce-reuse gate closed. No new SDK/role build or Source edits by this reviewer.

Latest atomic retirement read-only pass: /tmp/ziggy-starknet-retirement-final-review.md. No additional code blocker at unchanged five-production-file snapshot; current45/46 integration gate remains owner work, final approval awaits release+green/hash comparison.

Final Root/Operation atomic-retirement review accepted released95/95 zeroSkip atall16matchingfrozenSource hashes; see /tmp/ziggy-starknet-retirement-final-review.md and final-result.json. Separate direct generic-VM timeout Source audit remains /tmp/ziggy-generic-physical-timeout-review.md.
