const std = @import("std");
const worker = @import("worker");
test "worker RSS applies to exec image rather than inherited parent pages" {
    const pages = try std.heap.page_allocator.alloc(u8, 256 * 1024 * 1024);
    defer std.heap.page_allocator.free(pages);
    @memset(pages, 0x51);
    const args = try std.testing.allocator.alloc([]const u8, 3000);
    defer std.testing.allocator.free(args);
    args[0] = "/usr/bin/python3";
    args[1] = "/work/zig/src/aleo/testing/worker_fixture.py";
    const filler = "x" ** 256;
    @memset(args[2..], filler);
    for (0..100) |_| {
        var session = try worker.Session.spawn(std.testing.allocator, args, .{ .timeout_ms = 5000, .memory_bytes = 48 * 1024 * 1024 });
        defer session.deinit();
        const output = try session.exchange(.program_info, "echo");
        defer std.testing.allocator.free(output);
        try std.testing.expectEqualStrings("echo", output);
    }
    try std.testing.expectEqual(@as(u8, 0x51), pages[pages.len - 1]);
}
