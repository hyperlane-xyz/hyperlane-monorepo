# Read-only global Zig cache task association audit

Global cache remains protected. No deletion, policy relaxation, build, or benchmark was performed. No exclusive ownership/deletion whitelist is approved by this report.

Snapshot 2026-11-06T10:01:51.362498+00:00 to 2026-11-06T10:03:01.267807+00:00. `/Users/pbio/.cache/zig` contains 11,494 regular files, 26,805,428,224 allocated bytes (24.965 GiB). All five cache areas were inventoried. No symlinks encountered. Task birth cutoff interpreted as 2026-11-05 13:07 UTC.

Exact-match association: 2,874 stable Mach-O/ELF compiler outputs born after the cutoff contain the exact `/Users/pbio/work/ziggy/zig/src` byte sequence. They total 22,556,279,448 logical bytes and 22,590,910,464 allocated bytes (21.039 GiB). Every match was hashed; only path/stat metadata, hash chunks, and booleans are emitted. No binary strings or key material were printed or retained.

| Associated output | Files | Allocated GiB |
| --- | ---: | ---: |
| objects | 1,511 | 13.742 |
| test executables | 1,315 | 6.565 |
| other compiled outputs | 48 | 0.732 |

All 2,874 matches have link count one and are absent from both successful global `lsof -nP -Fpn` snapshots (exit zero). Reads encountered zero errors and zero mutation races. Associated birth times span 2026-11-05T13:14:12.960359+00:00 through 2026-11-06T09:59:13.106018+00:00.

Ownership confidence: strong direct association with this task's source checkout and time window; **exclusive global-cache ownership remains unproven**. No hard links and no open handles do not establish absence of cache-manifest/dependency references, concurrent future reuse, APFS cloned/shared extents, or another build's use of an identical cached artifact. This scan does not interpret all Zig cache dependency graphs and cannot certify the requested no-shared-references condition. Therefore the number proven safe to delete under the existing protection policy is zero.

Nonmatching standard-library/shared outputs, archives, text/cache metadata, and outputs without post-cutoff birth evidence are excluded from the association set. The remaining 4,214,517,760 allocated bytes (3.925 GiB) cannot be attributed by this method. Association bytes are an inventory upper bound, not promised host-space recovery. Existing role/runtime exports, source, fixtures, parameters, toolchains, and evidence paths were untouched.

Machine evidence: `/tmp/ziggy-global-cache-readonly-audit.json`; exact read-only scanner: `/tmp/ziggy-global-cache-readonly-audit.py`. Both preserved losslessly in the artifact manifest. SHA256 chunks concatenate in order. This report provides capacity information for Parent; it does not authorize crossing the user-global-cache boundary.
