from pathlib import Path
import os,stat,json,hashlib,mmap,datetime,subprocess,time,collections
root=Path('/Users/pbio/.cache/zig');needle=b'/Users/pbio/work/ziggy/zig/src';cutoff=datetime.datetime(2026,11,5,13,7,tzinfo=datetime.timezone.utc).timestamp();started=datetime.datetime.now(datetime.timezone.utc).isoformat()
def opened():
 p=subprocess.run(['lsof','-nP','-Fpn'],capture_output=True,text=True,timeout=40);result={};pid=None
 for line in p.stdout.splitlines():
  if line.startswith('p'):pid=line[1:]
  elif line.startswith('n') and line[1:].startswith(str(root)+'/'):result.setdefault(line[1:],[]).append(pid)
 return result,p.returncode
before_open,lsof_before_rc=opened();groups=collections.defaultdict(lambda:collections.Counter());formats=collections.defaultdict(lambda:collections.Counter());candidates=[];errors=[];symlinks=[];unstable=[];count=0
machos={bytes.fromhex(x) for x in ['feedface','cefaedfe','feedfacf','cffaedfe','cafebabe','bebafeca','cafebabf','bfbafeca']}
for folder,dirs,files in os.walk(root,followlinks=False):
 for d in dirs[:]:
  p=Path(folder,d)
  if p.is_symlink():symlinks.append(str(p));dirs.remove(d)
 for name in files:
  path=Path(folder,name)
  try:
   st=path.lstat()
   if stat.S_ISLNK(st.st_mode):symlinks.append(str(path));continue
   if not stat.S_ISREG(st.st_mode):continue
   rel=path.relative_to(root);group=rel.parts[0];count+=1;groups[group].update(files=1,logical_bytes=st.st_size,allocated_bytes=st.st_blocks*512)
   with path.open('rb') as f:magic=f.read(8)
   kind='Mach-O' if magic[:4] in machos else ('ELF' if magic[:4]==b'\x7fELF' else ('archive' if magic==b'!<arch>\n' else 'other'))
   formats[kind].update(files=1,logical_bytes=st.st_size,allocated_bytes=st.st_blocks*512)
   born=getattr(st,'st_birthtime',None)
   if kind not in ('Mach-O','ELF') or born is None or born<cutoff:continue
   with path.open('rb') as f:
    with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:bound=m.find(needle)>=0
   if not bound:continue
   digest=hashlib.sha256()
   with path.open('rb') as f:
    while block:=f.read(1024*1024):digest.update(block)
   after=path.lstat();stable=(st.st_dev,st.st_ino,st.st_size,st.st_mtime_ns)==(after.st_dev,after.st_ino,after.st_size,after.st_mtime_ns)
   if not stable:unstable.append(str(path));continue
   h=digest.hexdigest();candidates.append({'path':str(path),'format':kind,'logical_bytes':st.st_size,'allocated_bytes':st.st_blocks*512,'birth_utc':datetime.datetime.fromtimestamp(born,datetime.timezone.utc).isoformat(),'mtime_ns':st.st_mtime_ns,'mode':oct(stat.S_IMODE(st.st_mode)),'uid':st.st_uid,'gid':st.st_gid,'nlink':st.st_nlink,'dev':st.st_dev,'ino':st.st_ino,'sha256_chunks':[h[:32],h[32:]],'exact_root_binding':True,'stable_during_read':True,'open_pids_before':sorted(set(before_open.get(str(path),[])))})
  except (OSError,ValueError) as e:errors.append({'path':str(path),'error':type(e).__name__})
after_open,lsof_after_rc=opened()
for item in candidates:item['open_pids_after']=sorted(set(after_open.get(item['path'],[])))
closed=[x for x in candidates if not x['open_pids_before'] and not x['open_pids_after'] and x['nlink']==1]
result={'status':'read_only_information_only_global_cache_remains_protected','started_utc':started,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'root':str(root),'cutoff_utc':'2026-11-05T13:07:00+00:00','cutoff_assumption':'Task fresh checkout timestamp interpreted in UTC; birth alone does not prove task ownership','needle_sha256_chunks':[hashlib.sha256(needle).hexdigest()[:32],hashlib.sha256(needle).hexdigest()[32:]],'groups':{k:dict(v) for k,v in groups.items()},'formats':{k:dict(v) for k,v in formats.items()},'files':count,'candidates':candidates,'candidate_count':len(candidates),'candidate_logical_bytes':sum(x['logical_bytes'] for x in candidates),'candidate_allocated_bytes':sum(x['allocated_bytes'] for x in candidates),'closed_single_link_candidate_count':len(closed),'closed_single_link_candidate_allocated_bytes':sum(x['allocated_bytes'] for x in closed),'lsof_returncodes':[lsof_before_rc,lsof_after_rc],'symlinks':symlinks,'unstable':unstable,'errors':errors,'qualifications':['Exact embedded root binding and post-cutoff birth are direct task-association evidence, not exclusive global-cache ownership proof.','No active handles at two lsof snapshots and nlink=1 do not prove absence of cache-manifest/shared build references or future use.','Raw binary strings were searched in-process and never emitted; no binary content or secret material is included.','Archives/other formats and unbound standard-library/shared outputs excluded from candidate list.','No cache entries, policies, compilation or benchmarks were changed.']}
Path('/tmp/ziggy-global-cache-readonly-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['files','candidate_count','candidate_logical_bytes','candidate_allocated_bytes','closed_single_link_candidate_count','closed_single_link_candidate_allocated_bytes','lsof_returncodes']},indent=2));print('errors',len(errors),'unstable',len(unstable))
