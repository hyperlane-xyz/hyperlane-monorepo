from pathlib import Path
import os,stat,json,hashlib,mmap,datetime,subprocess,collections,re,gzip,struct
source=Path('/tmp/ziggy-global-cache-readonly-audit.json');audit=json.loads(source.read_text());needle=b'/Users/pbio/work/ziggy/zig/src';oldest_cutoff='2026-11-06T09:00:00+00:00';goal=6*1024**3;buffered_goal=int(6.25*1024**3);begin=datetime.datetime.now(datetime.timezone.utc).isoformat()
candidates=sorted((i for i in audit['candidates'] if Path(i['path']).name=='test'),key=lambda i:(i['birth_utc'],i['path']))
by_path={i['path']:i for i in candidates};references=collections.defaultdict(list);commands=collections.defaultdict(list);scanned=0;scan_errors=[];large_skips=[]
# Metadata only: preserve task commands/logs; never emit their bodies or binary strings.
paths=set(Path('zig/bench/results').rglob('*'))|set(Path('/tmp').glob('ziggy-*command*.json'))|set(Path('/tmp/ziggy-container-acceptance').glob('*.json'))
cache_pat=re.compile(r'/Users/pbio/\.cache/zig/o/[a-fA-F0-9]+/test(?:\b|$)');root_pat=re.compile(r'(?:/Users/pbio/work/ziggy/)?zig/src/[A-Za-z0-9_./-]+\.zig')
for path in sorted(paths):
 if not path.is_file() or path.is_symlink():continue
 if 'global-zig-cache-readonly-audit' in path.parts:continue  # Our ownership inventory is not a runtime/evidence dependency.
 name=path.name
 if not (name.endswith(('.json','.json.gz','.log','.txt','.md','.py'))):continue
 if path.stat().st_size>32*1024**2:large_skips.append(str(path));continue
 try:
  raw=path.read_bytes();raw=gzip.decompress(raw) if name.endswith('.gz') else raw
  if len(raw)>64*1024**2:large_skips.append(str(path));continue
  text=raw.decode('utf-8',errors='replace');scanned+=1
  for match in set(cache_pat.findall(text)):
   if match in by_path:references[match].append(str(path))
  if 'command' in name or (path.suffix=='.py' and 'zig test' in text):
   for item in set(root_pat.findall(text)):
    rel=item.removeprefix('/Users/pbio/work/ziggy/');commands[rel].append(str(path))
 except (OSError,ValueError,EOFError) as e:scan_errors.append({'path':str(path),'error':type(e).__name__})
def opened():
 r=subprocess.run(['lsof','-nP','-Fpn'],capture_output=True,text=True,timeout=45);items={};pid=None
 for line in r.stdout.splitlines():
  if line.startswith('p'):pid=line[1:]
  elif line.startswith('n') and line[1:] in by_path:items.setdefault(line[1:],[]).append(pid)
 return items,r.returncode,bool(r.stderr.strip())
open_before,rc1,warn1=opened();eligible=[];excluded=[];headers=collections.Counter();errors=[]
known_roots=sorted((r.encode(),r) for r in commands if Path(r).parent==Path('zig/src'))
for original in candidates:
 p=Path(original['path']);reasons=[]
 try:
  st=p.lstat()
  if not stat.S_ISREG(st.st_mode) or p.is_symlink():reasons.append('not_regular_non_symlink')
  if st.st_nlink!=1:reasons.append('hardlinked')
  if not st.st_mode&0o111:reasons.append('no_executable_mode')
  if st.st_size!=original['logical_bytes'] or st.st_mtime_ns!=original['mtime_ns'] or st.st_ino!=original['ino']:reasons.append('metadata_changed_since_audit')
  with p.open('rb') as f:
   head=f.read(64);magic=head[:4];executable=False;kind='unaccepted'
   if magic in (bytes.fromhex('feedface'),bytes.fromhex('feedfacf'),bytes.fromhex('cefaedfe'),bytes.fromhex('cffaedfe')):
    endian='>' if magic in (bytes.fromhex('feedface'),bytes.fromhex('feedfacf')) else '<';filetype=struct.unpack_from(endian+'I',head,12)[0];executable=filetype==2;kind='Mach-O MH_EXECUTE' if executable else 'Mach-O other'
   elif magic==b'\x7fELF':
    endian='<' if head[5]==1 else '>';et=struct.unpack_from(endian+'H',head,16)[0];executable=et==2;kind='ELF ET_EXEC' if executable else 'ELF other'
   if not executable:reasons.append('not_verified_executable_header')
   headers[kind]+=1
   with mmap.mmap(f.fileno(),0,access=mmap.ACCESS_READ) as m:
    if m.find(needle)<0:reasons.append('exact_checkout_binding_absent')
    # Root paths are metadata; this gives corroboration, not an exact invocation/mode claim.
    related=[r for b,r in known_roots if m.find(b)>=0]
  digest=hashlib.sha256()
  with p.open('rb') as f:
   while b:=f.read(1024*1024):digest.update(b)
  h=digest.hexdigest()
  if [h[:32],h[32:]]!=original['sha256_chunks']:reasons.append('digest_changed_since_audit')
  end=p.lstat()
  if (st.st_size,st.st_mtime_ns,st.st_ino)!=(end.st_size,end.st_mtime_ns,end.st_ino):reasons.append('changed_during_validation')
  if original['birth_utc']>=oldest_cutoff:reasons.append('newer_than_expired_candidate_cutoff')
  if open_before.get(str(p)):reasons.append('open_before')
  if references.get(str(p)):reasons.append('explicit_task_evidence_path_reference_preserved_conservatively')
  item={**original,'header':kind,'corroborating_source_roots':related,'corroborating_command_artifacts':sorted({v for r in related for v in commands[r]})[:20],'explicit_task_references':references.get(str(p),[]),'open_pids_before':open_before.get(str(p),[])}
  if reasons:excluded.append({'path':str(p),'reasons':reasons,'allocated_bytes':st.st_blocks*512,'references':references.get(str(p),[])})
  else:eligible.append(item)
 except (OSError,ValueError) as e:errors.append({'path':str(p),'error':type(e).__name__})
open_after,rc2,warn2=opened();stable=[]
for item in eligible:
 item['open_pids_after']=open_after.get(item['path'],[])
 if item['open_pids_after']:excluded.append({'path':item['path'],'reasons':['open_after'],'allocated_bytes':item['allocated_bytes']})
 else:stable.append(item)
selected=[];size=0
for item in stable:
 if size>=buffered_goal:break
 selected.append(item);size+=item['allocated_bytes']
ref_stats={p:paths for p,paths in references.items()};total_eligible=sum(i['allocated_bytes'] for i in stable)
procs=subprocess.run(['pgrep','-fl',r'^.*/zig (test|build)|(^|/)(clang|rustc|cargo)( |$)'],capture_output=True,text=True)
result={'status':'PROPOSAL_ONLY_NO_DELETION_AUTHORIZED_OR_EXECUTED','begin_utc':begin,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'input_audit_sha256_chunks':[hashlib.sha256(source.read_bytes()).hexdigest()[:32],hashlib.sha256(source.read_bytes()).hexdigest()[32:]],'scope':'Only cached basename=test executable outputs associated with this task; all objects/metadata/other outputs are excluded','task_birth_cutoff_utc':'2026-11-05T13:07:00+00:00','expired_candidate_birth_cutoff_utc':oldest_cutoff,'requested_recovery_bytes':goal,'allocated_selection_goal_bytes':buffered_goal,'all_test_executable_candidates':len(candidates),'verified_headers':dict(headers),'eligible_count':len(stable),'eligible_allocated_bytes':total_eligible,'selected_count':len(selected),'selected_allocated_bytes':size,'selected_logical_bytes':sum(i['logical_bytes'] for i in selected),'selected':selected,'unselected_eligible_count':len(stable)-len(selected),'excluded':excluded,'evidence_metadata_files_scanned':scanned,'evidence_metadata_scan_errors':scan_errors,'evidence_metadata_large_files_skipped':large_skips,'explicit_task_cache_references':ref_stats,'validation_errors':errors,'lsof_exitcodes':[rc1,rc2],'lsof_warned':[warn1,warn2],'compilers_snapshot':procs.stdout.splitlines(),'preconditions':['Parent explicitly accepts exact-output preservation scope in place of blanket cache-location protection.','All Zig/Rust/C compiler jobs and test children joined; recapture lsof and validate each exact metadata/header/root-binding/SHA immediately before any later authorized mutation.','Exclude every object, cache manifest, source/data/fixture, dependency/library, runtime or pin binary, and every unlisted path.','Preserve all raw commands/logs, task pinned runtimes and runtime loader closure, sources, SDKs, parameters, evidence, and selected whitelist with before/after hashes.'],'consequences':['These are generated historical test executable outputs; a later exact rerun may require test relink/rebuild. Their cache metadata and objects stay preserved.','Potential future cache reuse is an ordinary cache tradeoff, not proof of unrelated ownership.','The 6.25GiB allocated selection is a buffer toward 6GiB physical recovery, not a host df guarantee: APFS sharing and unrelated host writes can change actual recovery.','Observe host free space after any independently authorized operation; no silent cold-build floor relaxation.'],'ownership_concerns':['One referenced historical test path is conservatively excluded when found in retained task evidence; source-command correlation is corroborating, not proof of exact invocation or optimization mode.','No shared-role/runtime executable is selected: basename=test plus MH_EXECUTE/ET_EXEC, exact source binding and byte hash constrain purpose; objects and all other basenames are excluded.']}
Path('/tmp/ziggy-narrow-test-cache-plan.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ['all_test_executable_candidates','verified_headers','eligible_count','eligible_allocated_bytes','selected_count','selected_allocated_bytes','selected_logical_bytes','lsof_exitcodes','lsof_warned']},indent=2));print('excluded',len(excluded),'errors',len(errors),'evidence_scan',scanned)
