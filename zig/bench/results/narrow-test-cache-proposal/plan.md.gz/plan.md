# Narrow historical cached test executable proposal

Status: informational whitelist only. No deletion occurred. **Execution blocked** until Root's isolated Zig0.15.2 FileNotFound canary is resolved with an exact, Root-bound companion cache-manifest invalidation procedure and independent review. Removing only a cached executable or its output directory does not self-heal under the current manifests. This is an actual tool behavior concern, not a demand to exclude all possible future cache reuse.

The whitelist contains only basename `test` regular, non-symlink, mode-executable files with verified Mach-O MH_EXECUTE headers, exact checkout src binding, post-task birth and matching stable SHA256 from the original read-only audit. Objects, libraries, role outputs, data/source/assets, all metadata and every other basename are excluded. All1315 original basename-test candidates have actual MH_EXECUTE headers; no ELF/other type was admitted by a filename guess.

- Original test executable inventory:1315 files, about6.565GiB allocated.
- Historical eligible set before09:00 UTC Nov6:1290 files, 6.362GiB allocated.
- Proposed oldest subset:1264 files, 6,716,342,272 allocated bytes (6.255GiB), 6,713,820,128 logical bytes. Birth range 2026-11-05T13:14:44.080169+00:00 to 2026-11-06T07:55:37.558230+00:00.
- Selection targets6.25GiB allocated as a buffer toward6GiB recovery; APFS sharing/unrelated writes still require actual host free-space readback. This is not an executable reclaim claim or a cold-floor waiver.

Revalidation found no metadata/hash changes or read errors. Every selected file has link count1 and no handles in either successful lsof snapshot (no warnings). No task symlink alias to a selected path was found in the bounded zig tree and top-level ziggy temporary-path scan. This is not a scan of every possible filesystem alias.

Preservation review: all role/runtime/pinned binary paths are outside this basename-test cache scope and remain untouched. No object or runtime dependency is selected. All raw command/log evidence, manifests, source, toolchains, SDKs, fixtures/parameters and license/data paths remain. Six cached executable paths appearing in raw task evidence are conservatively excluded (two also lie in the21 newest excluded outputs). The25 total exclusions are recorded explicitly. Newer final acceptance binaries are retained.

Correlation:1514 task command/result/log metadata files were searched without printing their bodies. Six explicit cached-path references map to scraper process snapshots, runtime timeout/default wiring diagnostics and earlier global failure logs; those paths are excluded. Selected successful test runs generally do not log their selected global cache path. Matching exact invocation/root/optimization mode was not feasible from the recorded command strings and split debug path layout; no such exact correlation is claimed. Exact src binding, generated executable header, birth window and stable per-file hash provide direct task-output association.

Realistic consequence once correct manifest invalidation is proven: historical test commands will need a test relink/rebuild; they do not represent pinned production role runtimes. Losing a possible future test cache hit is the ordinary cache tradeoff and is not itself unrelated ownership. However the current FileNotFound failure must be addressed first; do not remove broad/global metadata to work around it. Root's controlled canary may justify a narrowly reviewed companion manifest set later.

Any later execution must be separately authorized, wait for all host/container compiler/test jobs to join, recapture handles, revalidate exact inode/size/mode/header/src-binding/hash for each whitelisted path, preserve all protected outputs and evidence hashes, and report observed host free bytes. No existing helper's owned-root protections were relaxed. The global cache protection policy is unchanged by this proposal.

Exact whitelist and SHA256 chunks: `/tmp/ziggy-narrow-test-cache-plan.json`. Read-only validator: `/tmp/ziggy-narrow-test-cache-plan.py`. Artifacts include the isolated canary result/logs without any canary or global mutation by this reviewer.
